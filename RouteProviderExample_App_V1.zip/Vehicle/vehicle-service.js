(function(){
    
    angular.module("vehicles")
           .service("vehicleSvc",["$http",function($http){
                
                this.getVehicleDetails = function(){
                    
                    return $http.get("API/vehicles.json");
                    
                };                
            }]);
})();
