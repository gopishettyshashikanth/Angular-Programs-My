(function(){
    
    angular.module("vehicleDetails",["ngRoute","register","login","lookup","vehicles","components","home","angularUtils.directives.dirPagination"])
        
    /*angular.module("vehicleDetails",['ngRoute','home','register','vehicles','login'])*/
           .config(['$routeProvider',function($routeProvider){
            
            $routeProvider.when('/', {
				templateUrl : 'templates/home.html',
				controller  : 'homeCtrl'
			})
			.when('/vehicle', {
				templateUrl : 'templates/vehicle.html',
				controller  : 'vehicleCtrl'
			})
			.when('/login', {
				templateUrl : 'templates/login.html',
				controller  : 'loginCtrl'
			})
            .when('/register', {
				templateUrl : 'templates/register.html',
				controller  : 'registerCtrl'
			})
            .when('/home', {
				templateUrl : 'templates/home.html',
				controller  : 'homeCtrl'
			});    
    }]);	
    
   /* app.controller('homeCtrl', function($scope) {
		// create a message to display in our view
		$scope.message = 'Everyone come and see how good I look!';
	});*/
    
})();

