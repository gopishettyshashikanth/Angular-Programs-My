(function(){
    
    angular.module("login",["ui.router","home"])
            .controller("loginCtrl",function($scope,$state,$location){
            
                $scope.loginUser = function(){
                        
                    console.log($scope.userDetails.userName);
                    
                    if($scope.userDetails.userName === "shashi" && $scope.userDetails.password === "shashi"){
                        
                        console.log("correct");
                        //$state.go('home');
                         $location.path("/home" );
                        
                    }else{
                        
                        console.log("Incorrect");    
                        $scope.errorMsg="Login not correct";                    
    
                    }  
                } 
            });    
})();