(function(){
	angular.module("student")
	       .controller("studentCtrl",["$scope","studentSvc","$http",
							function($scope,studentSvc,$http){
							
				studentSvc.getStdDetails()
				
				.then(function(response){
					$scope.Details = response.data.Details;
				})
				.catch(function(response){
					$scope.showError = response;	
				});	
				
				studentSvc.getStdMarks()
				
				.then(function(response){
					$scope.Marks = response.data.Marks;
				})
				.catch(function(response){
					$scope.showError = response;	
				});
				
				$scope.Marks = studentSvc.getStdMarks();
				
				$scope.getMarks = function(index){
					
					$scope.marksHeader = true;
					
					$scope.marksList = [];
					 					 
					  angular.forEach($scope.Marks,function(item){
												
						if(item.Sid === index){
                   
							$scope.marksList.push(item);   
						}  
					});
				}

				$scope.addDetails = function(){
					console.log("student cmng");
					
				}								
			}]);		
})();