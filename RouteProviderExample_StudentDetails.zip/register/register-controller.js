(function(){
    
    angular.module("register",["ui.router","login"])
            .controller("registerCtrl", function($scope,lookupSvc,$location){
        
        $scope.userDetails={};
		       
        $scope.countries = lookupSvc.getCountryList();
        
       // console.log($scope.countries);
        
        $scope.states= lookupSvc.getStateList();
        
        $scope.registerUser = function(){
           // console.log($scope.userDetails);    
        }
        
       $scope.loadStates = function(){
            
            $scope.statesList = [];
            
            angular.forEach($scope.states,function(item){
                
                if(item.countryCode === $scope.selectedCountry.key){
                   
                    $scope.statesList.push(item);   
                }  
            });
           // console.log($scope.statesList);
        };	

		$scope.signFun = function(){
					$location.path("/login");
			}	
    });
    
})();