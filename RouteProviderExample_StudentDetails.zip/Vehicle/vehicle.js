(function(){
    
    angular.module("vehicles",[]);
    
    
})()