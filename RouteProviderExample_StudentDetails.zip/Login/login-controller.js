(function(){
    
    angular.module("login",["ui.router","home","register"])
            .controller("loginCtrl",function($scope,$state,$location){
            
                $scope.loginUser = function(){
                        
					console.log($scope.userDetails.email);
                    
                    if($scope.userDetails.email === "shashi@gmail.com" && $scope.userDetails.password === "shashi"){
                        
                        console.log("correct");
                        //$state.go('home');
                        $location.path("/home");
                        
                    }else{
                        
                       console.log("Incorrect");  							
                       $scope.errorMsg="Invalid username and password"; 
											   
                    }  
                }
				
				$scope.signupFun = function(){
					console.log("register");
					$location.path("/register");					
				}	
				
            }); 
			
				

			
})();