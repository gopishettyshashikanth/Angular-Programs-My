(function(){
    
    angular.module("lookup",[]);
    
    
})()