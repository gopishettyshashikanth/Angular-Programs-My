<?php
error_reporting(0);
ob_start();
session_start();
header("Expires: 0");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("cache-control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
$db_host = "localhost";
$db_username = "root";
$db_password = "";
$db_name = "dynapac_library";
$conn = mysql_connect($db_host, $db_username, $db_password);
if ($conn) {
    mysql_select_db($db_name);
}
?>