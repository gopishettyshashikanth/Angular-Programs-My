<!DOCTYPE html>
<?php
error_reporting(0);
include_once "connect.php";	
$count;
	
	$varFormPostDescription = mysql_real_escape_string($_POST['formPostDescription']);
	
	if(isset($_POST["submit"]))
	{
		$desctxt = $_POST['desctxt'];
				
		if($desctxt != "")
			{		
				//$sql = "INSERT INTO announcements (description) VALUES ('$desctxt')";								
				
				$sql = "UPDATE announcements SET description='$desctxt' where ID=0";													
				$query = mysql_query($sql) or die(mysql_error());
		
				header("Location:announcements.php?mode=success");
			}else{
				
				header("Location:announcements.php?mode=fill");
			}		
	}
?>
<html>
<head>
	<meta charset="UTF-8" />
	<title>CHRP Library</title>
	<link rel='stylesheet' href='css/jquery-ui.css' />
    <link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
	<script src="js/jquery-1.11.1.min.js"></script>
	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
	</script>

</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload=""><br/>

	
	
	
</body>
</html>