<!DOCTYPE html>
<?php
	include "banner.php";
?>
<html>
<head>
	<title>Dynapac Course Library</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel='stylesheet' href='css/jquery-ui.css'/>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.min.js"></script>
	
	<link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
	
	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
	</script>
	
	<style>
	 .imgcontainer {
				text-align: center;
				margin: 24px 0 12px 0;
				color : #0099cc;
				font-size : 24px;
		}
	.submitBtn {
		background-color: #0099cc;
		color: white;
		padding: 14px 0px;
		margin: 10px 0;
		border: none;
		cursor: pointer;
		width: 30%;
		margin-left:70%;
	}
	</style>
</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="" class="boxed">
	
<div class="container-fluid">

	<div id="loginbox" class="mainbox col-md-6 col-sm-8">
		<div class="panel panel-info">
						
			<div class="panel-body">
				
				<form class="form-horizontal" action="checkUser.php" method="post">
					
					<div class="imgcontainer">
						FORGOT PASSORD
					</div>
											
					<div>
						<label for="email">Email:</label>
							
						<input type="text" name="mail" placeholder="Enter Email">
							
						<label for="Security Text">Security Text:</label>
						<input type="text" name="security" placeholder="Security Text">
							
						<input type="submit" name="submit" class="submitBtn" style="background-color:#0099cc;"value="Submit" onclick="this.value='submitting';"/>
					</div>
																
					<div class="login-help">
							<?php
							if(isset($_GET['mode']))
							{
								if($_GET['mode']=='invalid')
								{
									echo "<span style=color:red;>Invalid eMail/SecurityText...</span>";
								}
								if($_GET['mode']=='fill')
								{
									echo "<span style=color:red;>Please fill all details...</span>";
								}
							}
							?>
					</div>	
				</form>	
			</div>
		</div>	
	</div>
</div>



	
</body>
</html>