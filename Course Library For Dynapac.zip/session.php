<!DOCTYPE html>
<?php
include_once "connect.php";
$check = $_SESSION['user'];
$adminMail = 'itdesk@chrp-india.com';

$query = mysql_query("SELECT * FROM users WHERE username='$check'") or die(mysql_error());
$counter = mysql_num_rows($query);
if($counter <= 0)
{
	mysql_close();
	header("Location:index.php");
}
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>CHRP Library</title>
	<link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
	<link rel="stylesheet" href="css/bootstrap.css">
	<script src="js/jquery.min.js"></script>
		
</head>
<body class="boxed">
		
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
	  
	  <img class="img-responsive" src="images/chrp.png" alt="logo" width="150px" height="80px"/>	  	  	  
    </div>
	
    <div class="collapse navbar-collapse" id="myNavbar">
      
	  <ul class="nav navbar-nav">
		 <li class="" style="font-size :20px; color:white"><a onMouseOver="this.style.color='#fff'">Course Library</a></li>	 
      </ul>
	  
      <ul class="nav navbar-nav navbar-right">
	    <li><a href="profile.php" style="color:#ffffff; font-size:14px;">Hi <?php echo $_SESSION["user"];?></a></li>
	  	<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>  Home</a></li>
		<li><a href="index.php">•   <span class="glyphicon glyphicon-log-in"></span>   LogOut</a></li>       
        <li><a href="mailto:itdesk@chrp-india.com?Subject=CHRP Library - Help">•   <span class="glyphicon glyphicon-envelope"></span>  Contact Admin</a></li>
      </ul>
	  
    </div>
  </div>
</nav>

</body>
</html>