<!DOCTYPE html>
<?php
	error_reporting(0);
	include "banner.php";
	session_start();
?>
<html>
<head>
	<title>Dynapac Course Library</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel='stylesheet' href='css/jquery-ui.css'/>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.min.js"></script>
	
  	<link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
	
	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
	</script>
	
	<style>
	 .imgcontainer {
				text-align: center;
				margin: 24px 0 12px 0;
				color : #0099cc;
				font-size : 24px;
		}
	.submitBtn {
		background-color: #0099cc;
		color: white;
		padding: 14px 0px;
		margin: 10px 0;
		border: none;
		cursor: pointer;
		width: 50%;
		margin-left:25%;
	}
	</style>
</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="" class="boxed">
	
	<div class="container-fluid">

	<div id="loginbox" class="mainbox col-md-6 col-sm-8">
		<div class="panel panel-info">
						
			<div class="panel-body">
					
				<form action="controlPanel.php" method="post" id="loginform">
				
						<div class="imgcontainer">
						LOGIN
						</div>
											
						<div>
							<label for="email">Username:</label>
							<input type="text" class="form-control" name="username" placeholder="Enter Username">
							
							<label for="pwd">Password:</label>
							<input type="password" name="password" class="form-control" placeholder="Enter password">
							
							<input type="submit" name="login" value="Login" class="submitBtn"/>
														 
						</div>
																
						<div class="form-group">
                            <div class="col-md-12">
                                <div>								
								<a href="forgot.php" style="color:#0099cc">Forgot Password</a>
                                <a href="register.php" style="color:#0099cc;float : right">Register</a> 								
								</div>							
                            </div>
						</div>			
                       
					<div class="login-help">
							<?php
							
							if(isset($_GET['mode']))
							{
							session_destroy();
								if($_GET['mode']=='invalid')
								{
									echo "<span style=color:red;>Invalid Username/Password...</span>";
								}
								if($_GET['mode']=='fill')
								{
									echo "<span style=color:red;>Enter Username/Password...</span>";
								}
								if($_GET['mode']=='inactive')
								{
									echo "<span style=color:red;>Your account is not activated<br/>wait for admin responce...</span>";
								}
								if($_GET['mode']=='block')
								{
									echo "<span style=color:red;>Your account is blocked<br/>contact admin for help...</span>";
								}
							}
							?>
					</div>						
				</form>	
								</div>
							</div>	
						</div>
					</div>
		
</body>
</html>