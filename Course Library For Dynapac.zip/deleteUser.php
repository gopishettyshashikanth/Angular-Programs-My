<?php
require_once "connect.php";

if(isset($_GET["mail"]))
{
	$mail = $_GET["mail"];
	$sql = "DELETE FROM users WHERE mail='".$mail."'";
	$query = mysql_query($sql) or die(mysql_error());
	mysql_close();
	header("Location:userAccounts.php?mode=success");
}
else
{
	header("Location:userAccounts.php?mode=pleaseFill");	
}
?>