<!DOCTYPE html>
<?php
	error_reporting(0);
	include("session.php");
	
	$config = parse_ini_file("config.ini");
	$config['url'] = basename($_SERVER['SCRIPT_NAME']);
	$f = fopen("config.ini","w");
	foreach($config as $name => $value)
	{
		fwrite($f, "$name = \"$value\"\n");
	}
	fclose($f);
?>
<html>
<head>	
	<title>Dynapac Course Library</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel='stylesheet' href='css/jquery-ui.css'/>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.min.js"></script>
		
	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
	</script>
	<style>
		img
		{
			border : 0;
		}
		a{
			text-decoration:none !important;
		}
	</style>
</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="" class="boxed">
	
<div class="container-fluid">	
	<p style="font-size:24px; color:#0099cc;">DASHBOARD</p>
	<div class="row">
	  <div class="col-md-2 col-md-offset-1">
		<div class="thumbnail">
		  <a href="search.php">
			<img src="images/search.png" alt="Search" style="">
			<div class="caption">
			  <p align="center">Search</p>
			</div>
		  </a>
		</div>
	  </div>
	  <div class="col-md-2">
		<div class="thumbnail">
		  <a href="upload.php">
			<img src="images/upload.png" alt="upload" style="">
			<div class="caption">
			  <p align="center">Upload</p>
			</div>
		  </a>
		</div>
	  </div>
	  <div class="col-md-2">
		<div class="thumbnail">
		  <a href="userAccounts.php">
			<img src="images/accounts.png" alt="Accounts" style="">
			<div class="caption">
			  <p align="center">Accounts</p>
			</div>
		  </a>
		</div>
	  </div>
	  <div class="col-md-2">
		<div class="thumbnail">
		  <a href="announcements.php">
			<img src="images/announcements.png" alt="announcements" style="">
			<div class="caption">
			  <p align="center">Announcements</p>
			</div>
		  </a>
		</div>
	  </div>
	  <div class="col-md-2">
		<div class="thumbnail">
		  <a href="">
			<img src="images/Calender.png" alt="Calender" style="">
			<div class="caption">
			  <p align="center">Calender</p>
			</div>
		  </a>
		</div>
	  </div>
	</div>
	
</div>
</body>
</html>