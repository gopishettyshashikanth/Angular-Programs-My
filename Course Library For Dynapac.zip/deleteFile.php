<?php
include_once "connect.php";

$tbl_name = 'images';
$isImg = true;

// get value of id that sent from address bar 
$file = $_GET['filename'];
$images = ["jpg","jpeg","png","gif","cptx","Storyline","mp3","mp4","fla","flv","wav","mkv","zip","pdf","flash","Captivate"];

// Delete data in mysql from row that has this file name 
$sql="DELETE FROM $tbl_name WHERE name='$file'";
$result = mysql_query($sql);

if($result)
{
	unlink("uploads/".$file);
	$extension = explode(".",$file)[1];
	if(!in_array($extension, $images))
	{
		$jpg = explode(".",$file)[0].".jpg";
		unlink("uploads/".$jpg);
		$isImg = false;
	}
	else{
		$myext = explode(".",$file)[1];
		$jpg = explode(".",$file)[0].".jpg";
		//unlink("uploads/".$myext."/".$file);
		
		unlink("uploads/Flash/"."/".$file);
		unlink("uploads/Captivate/"."/".$file);
		unlink("uploads/Storyline/"."/".$file);
		unlink("uploads/".$myext."/".$file);
		unlink("uploads/".$jpg);
		
		function delete_directory($dirname) {
		if (is_dir($dirname))
			$dir_handle = opendir($dirname);
			if (!$dir_handle)
				return false;
				while($file = readdir($dir_handle)) {
				if ($file != "." && $file != "..") {
					if (!is_dir($dirname."/".$file))
						 unlink($dirname."/".$file);
					else
						 delete_directory($dirname.'/'.$file);
					}
				}
			closedir($dir_handle);
			rmdir($dirname);
			return true;
		}
		
		delete_directory("uploads/".$myext."/".explode(".",$file)[0]);
		delete_directory("uploads/Flash/"."/".explode(".",$file)[0]);
		delete_directory("uploads/Captivate/"."/".explode(".",$file)[0]);
		delete_directory("uploads/Storyline/"."/".explode(".",$file)[0]);
		
		$isImg = false;
	}

	if($isImg == true)
	{
		unlink("thumbs/".$file);
	}
	else
	{
		$jpgThumb = explode(".",$file)[0].".jpg";
		unlink("thumbs/".$jpgThumb);
	}
	echo "Deleted Successfully " . $jpg;	
	header("location:search.php");
}
else
{
	header("location:search.php");
	echo "Error";
}

// close connection 
mysql_close();
?>