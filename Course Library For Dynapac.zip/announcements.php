<!DOCTYPE html>

<?php
	include("session.php");
	$config = parse_ini_file("config.ini");
	$config['url'] = basename($_SERVER['SCRIPT_NAME']);
	$f = fopen("config.ini","w");
	foreach($config as $name => $value)
	{
		fwrite($f, "$name = \"$value\"\n");
	}
	fclose($f);
?>
<html>
<head>

  <title>Dynapac Course Library</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel='stylesheet' href='css/jquery-ui.css' />
  
  <link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
  
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>	
  <script src="js/jquery-1.11.1.min.js"></script>
	
	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
	</script>
	
	<script type="text/javascript">	
		 function hide()
		{	
			alert(document.getElementById("Submit").value);
			document.getElementById("Submit").style.cursor = 'default';
			document.getElementById("Submit").disabled = true;
		}		
	</script>	
	
</head>
<body onload="noBack(); hide();" onpageshow="if (event.persisted) noBack();" onunload="">

	<!--<ul class="nav navbar-nav navbar-left">
		<li><a href="search.php">Search Course</a></li>
		<li><a href="upload.php">Upload Course</a></li>
		<li><a href="userAccounts.php">Manage Accounts</a></li>
		<li><a href="announcements.php" style="color : #0099cc;">Announcements</a></li>
		<li><a href="#">Calender</a></li>
	</ul> -->

<div class="container">

	<ul class="nav navbar-nav nav-lfet">
		<li><a href="search.php">Search Course</a></li>
		<li><a href="upload.php">Upload Course</a></li>
		<li><a href="userAccounts.php">Manage Accounts</a></li>
		<li><a href="announcements.php" style="color : #0099cc;">Announcements</a></li>
		<li><a href="#">Calender</a></li>
	</ul>

	<div id="loginbox" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
		<div class="panel panel-info">	
					
			<div style="padding-top:30px" class="panel-body">					
				<form id="myForm" action="announcementsDesc.php" method="post" enctype="multipart/form-data" class="form-horizontal">
																
						<div class="form-group">
							<label class="control-label col-sm-3" for="Description">Description:</label>
							<div class="col-sm-9">
							<textarea type="text" rows="5" class="form-control" name="desctxt" id="desctxt" placeholder="Enter Description" maxlength="255"style="height: 150px"></textarea>								
							</div>
						</div>							
														
						<div class="form-group">        
							<div class="col-sm-offset-3 col-sm-10">
															
								<input type="submit" name="submit" class="btn btn-primary" value="Submit" onclick="this.value='Submit';"/>					
							</div>
						</div>        
						<div class="login-help">
						<?php
							if(isset($_GET['mode']))
								{
									if($_GET['mode']=='success')
										echo "<span style=color:green;>Data is uploaded successfully!</span>";
									if($_GET['mode']=='fill')
										echo "<span style=color:red;>Please fill field.</span>";
									if($_GET['mode']=='exist')
										echo "<span style=color:red;>Already exist.</span>";
								}		
							?>	
					</div>							
					
					<div style="text-align: center;">		
					<a href="main.php">Back to Main</a>
					</div>
							
			</div>
					
				</form>	
					
			</div>
		</div>	
	</div>
</div>
							
</body>
</html>