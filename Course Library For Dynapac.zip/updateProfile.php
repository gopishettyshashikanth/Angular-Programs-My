<?php
require_once "connect.php";

if(isset($_POST["Submit"]))
{
	$user = $_SESSION['user'];
	$empid = trim($_POST['empid']);
	$pwd = trim($_POST['password']);
	$security = trim($_POST['security']);
	
	if($empid != "" && $pwd != "" && $security != "")
	{
		$sql = "UPDATE users SET emp_id='".$empid."', password='".$pwd."', security_txt='".$security."' WHERE username='".$user."'";
		$result = mysql_query($sql) or die(mysql_error());
		mysql_close();
		header("Location:profile.php?mode=success");
	}
	else
	{
		header("Location:profile.php?mode=pleaseFill");	
	}
}
?>