<!DOCTYPE html>
<?php
	error_reporting(0);
	include("session.php");
	$config = parse_ini_file("config.ini");
	$config['url'] = basename($_SERVER['SCRIPT_NAME']);
	$f = fopen("config.ini","w");
	foreach($config as $name => $value)
	{
		fwrite($f, "$name = \"$value\"\n");
	}
	fclose($f);
?>
<html>
<head>
	<title>Dynapac Course Library</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel='stylesheet' href='css/jquery-ui.css'/>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.min.js"></script>	
	<script src="js/jquery-1.11.1.min.js"></script>	
	
	<script type="text/javascript">
        function hide()
		{
			document.getElementById('fileZIP').style.display = 'none';
			document.getElementById('filesNew').value = '';
			document.getElementById('zipFileNew').value = '';
			
			document.getElementById('cname').value = "";
			document.getElementById('cdesc').value = "";
							
			document.getElementById('cate').value = "";
			document.getElementById('tag').value = "";	
			
			document.getElementById("Submit").style.cursor = 'default';
			document.getElementById("Submit").disabled = true;
		}
		function changeText()
		{	
			document.getElementById("cate").style.color = 'inherit';
			enableSubmit();
		}		
		function enableSubmit()
		{
			document.getElementById("Submit").disabled = false;
			document.getElementById("Submit").style.cursor = 'pointer';

			if(document.getElementById('fileJPG').style.display == 'inline')
			{
				if(document.getElementById('cate').value == "" || document.getElementById('tag').value == "" || document.getElementById('filesNew').value == ""||
				document.getElementById('cname').value == ""||
					document.getElementById('cdesc').value == "")
				{
					document.getElementById("Submit").disabled = true;
					document.getElementById("Submit").style.cursor = 'default';
				}
			}
			else
			{
				if(document.getElementById('cate').value == "" || document.getElementById('tag').value == "")
				{
					document.getElementById("Submit").disabled = true;
					document.getElementById("Submit").style.cursor = 'default';
				}				
			}			
		}
	</script>
	<script>
		$(document).ready(function()
		{
			$('input#cname').keyup(function()
			{
				enableSubmit();
			});
			$('input#cdesc').keyup(function()
			{
				enableSubmit();
			});
			$('textarea#tag').keyup(function()
			{
				enableSubmit();
			});
			$( "#Submit" ).click(function(event)
			{
				if($('#myForm').valid())
				{
					$(event.target).attr("disabled", "disabled");
				}
			});
		});
	</script>

	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
	</script>	
	<style>
	ul li
	{
		list-style:none;	
		text-decoration : none;
		display : inline;
		padding : 10px;	
		line-height : 10px;
		font-size : 14px;
	} 
	a{
		color: black;
		text-decoration: none;			
	}
	.imgcontainer {
				text-align: center;
				margin: 24px 0 12px 0;
				color : #0099cc;
				font-size : 24px;
		}
	
	</style>
</head>
<body onload="noBack(); hide();" onpageshow="if (event.persisted) noBack();" onunload="">
	
<div class="container-fluid">

<div>	
	<ul class="" class="nav navbar-nav" style="text-align: center; background-color:#dedede;">
		<li><a href="search.php">Search Course</a></li>	
		<li><a href="#" style="color : #0099cc;">Upload Course</a></li>		
		<li><a href="userAccounts.php">Manage Accounts</a></li>		
		<li><a href="announcements.php">Announcements</a></li>		
		<li><a href="#">Calender</a></li>
	</ul>
	
</div>
	
	<div id="loginbox" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
	
		<div class="panel panel-info">	
								
			<div class="panel-body">
					
<form id="myForm" action="uploadFile.php" method="post" enctype="multipart/form-data" class="form-horizontal">
									
	<div>
		<label for="Choose File">Choose File:</label>		
		<input type="file" id="files" name="files" name="username">
					
	</div>
							
	<div id="fileJPG">
		<label for="Thumbnail" id="filesNew_lbl">Thumbnail:</label>
		<div>
		<input type="file" id="filesNew" name="filesNew" value="" accept="image/jpeg">
		</div>	
	</div>
						
	<div id="fileZIP">		        
		<input type="file" id="zipFileNew" name="zipFile" value="" accept="application/zip">		
	</div>
						
	<div id="selectedFiles" align="center" class="selectedImage"></div>
						
	<div>
		<label for="inputEmail" class="control-label" id="cate_lbl">Course category:</label>
		
		<select class="form-control" name="category" id="cate" style="color:#aaa;" onchange="changeText();">
								
			<option value="Storyline" style="color:#000;">Storyline</option>
			<option value="Captivate" style="color:#000;">Captivate</option>
			<option value="Videos" style="color:#000;">Videos</option>
			<option value="Pdf" style="color:#000;">Pdf</option>
			<option value="Flash" style="color:#000;">Flash</option>
		</select>
		
		<label id="cname_lbl" for="email">Course Name:</label>		
		<input type="text" class="form-control input-sm" name="cname" id="cname" placeholder="Course Name">

		<label id="cdesc_lbl" for="email">Course Description:</label>		
		<input type="text" class="form-control" name="cdesc" id="cdesc" placeholder="Course Description">
		
		<label for="email" id="tag_lbl">Keywords:</label>
		<textarea type="text" rows="5" class="form-control" name="tag" id="tag" style="max-width:100%; min-height:70px;"  placeholder="Enter key words for searching this image" maxlength="255"></textarea>
		
		<input type="submit" id="Submit" name="Submit" value="Upload" class="btn btn-primary" onclick="this.value='Upload';"/>
		
	</div>
																    </form>	

	
<div style="text-align: center;">		
	<a href="main.php">Back to Main</a>
</div>
	
<script>
		var images = ["jpg","jpeg","png","gif"];
		var fileType = ["pdf","zip","mp4"];
		var selDiv = "";
		document.addEventListener("DOMContentLoaded", init, false);
		var img = document.createElement("img");
		var ext1,ext2;
		var fname1,fname2;
			
		function init()
		{
			document.querySelector('#files').addEventListener('change', handleFileSelect, false);
			selDiv = document.querySelector("#selectedFiles");
				
			document.querySelector('#filesNew').addEventListener('change', handleFileSelectNew, false);
			document.querySelector('#zipFileNew').addEventListener('change', handleFileSelectNew1, false);	
		}
		function handleFileSelect(e)
		{
			hide();
			if(!e.target.files || !window.FileReader) return;
			selDiv.innerHTML = "";
			var files = e.target.files;
			var filesArr = Array.prototype.slice.call(files);

			filesArr.forEach(function(f)
			{
				fname1 = f.name.split('.')[0];
				ext1 = (f.name.split('.').pop()).toLowerCase();
				var reader = new FileReader();
				reader.onload = function (e)
					{
						if(fileType.indexOf(ext1) == -1)
						{
							selDiv.innerHTML = "<b><font face='verdana' color='red' size=2>Unknown File Format!!!</font></b>";
							return;
						}
						if(Math.round(f.size/1024) >= 512000)
						{
							selDiv.innerHTML = "<b><font face='verdana' color='red' size=2>File is too large! <br/> (max size : 50MB)</font></b>";
							return;
						}
						
						if(images.indexOf(ext1) == -1)
						{
							img.src = "images/icons/" + ext1 + ".png";
							if(ext1 == "mp4" || ext1 == "pdf")
							{
								document.getElementById('fileJPG').style.display = 'inline';
							}
							else if(ext1 == "zip"){
								
								document.getElementById('fileJPG').style.display = 'inline';
								
								document.getElementById('fileZIP').style.display = 'none';
							}
						}
						else
						{
							img.src = e.target.result;
						}
					}
					reader.readAsDataURL(f);
				});
			}
			function handleFileSelectNew(e)
			{
				enableSubmit();
				var filesArr = Array.prototype.slice.call(e.target.files);				
				filesArr.forEach(function(f)
				{
					fname2 = f.name.split('.')[0];
					ext2 = (f.name.split('.').pop()).toLowerCase();

					if(fname1 != fname2 || ext2 != "jpg")
					{
						alert("Please Select JPG file with the same name...!");
						document.getElementById('filesNew').value = '';
						enableSubmit();
					}
					else
					{
						var reader = new FileReader();
						reader.onload = function (e)
						{
							document.getElementById('im').src = e.target.result;
						}
						reader.readAsDataURL(f);
					}
				});
			}
			
			function handleFileSelectNew1(e)
			{
				enableSubmit();
				var filesArr = Array.prototype.slice.call(e.target.files);				
				filesArr.forEach(function(f)
				{
					fname2 = f.name.split('.')[0];
					ext2 = (f.name.split('.').pop()).toLowerCase();

					if(fname1 != fname2 || ext2 != "zip")
					{
						alert("Please Select zip file with the same name...!");
						document.getElementById('zipFileNew').value = '';
						enableSubmit();
					}
					else
					{
						var reader = new FileReader();
						reader.onload = function (e)
						{
							document.getElementById('im').src = e.target.result;
						}
						reader.readAsDataURL(f);
					}
				});
			}
			
</script>
	<div class="login-help">
		<?php
			if(isset($_GET['mode']))
			{
				if($_GET['mode']=='success')
					echo "<span style=color:green;>File is uploaded successfully!</span>";
				if($_GET['mode']=='fill')
					echo "<span style=color:red;>Please fill all fields...</span>";
				if($_GET['mode']=='exist')
					echo "<span style=color:red;>Already exist.</span>";
				if($_GET['mode']=='fail')
					echo "<span style=color:red;>Please upload file with max size 100MB only...</span>";
				if($_GET['mode']=='incorrect')
					echo "<span style=color:red;>Please upload correct format...</span>";
				switch($_GET['mode'])
				{
					case 1:
					case 2:
						echo "<span style=color:red;>The uploaded file exceeds the MAX_FILE_SIZE (500MB).</span>";
						break;
					case 3:
					case 4:
					case 5:
					case 6:
					case 7:
						echo "<span style=color:red;>No file was uploaded!</span>";
						break;
				}
			}
		?>
	</div>
		
		
								</div>
							</div>	
						</div>
						
					</div>
</body>
</html>