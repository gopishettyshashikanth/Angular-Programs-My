<?php
require_once "connect.php";
/*
we post the variables we recieve from POST method
*/
$mail = $_POST['mail'];
$security = $_POST['security'];

if($mail != "" && $security != "")
{
	$sql = "SELECT * FROM users WHERE mail='$mail' && security_txt='$security';";
	$query = mysql_query($sql) or die(mysql_error());
	$counter = mysql_num_rows($query);
	mysql_close();
	
	$headers = 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	
	if ($counter > 0)
	{
		while ($data = mysql_fetch_array($query))
		{
			$subject = "CHRP Library Login details";
			$body = "<div style='font-family:verdana; font-size:14px;'>Hi, <br/><br/>Your CHRP-Library login details<br/><br/>UserName : ".$data['username']."<br/>Password : ".$data['password']."<br/>Security Text : ".$data['security_txt']."<br/><br/>Click here to <a style='text-decoration: none;' href='http://chrp-india.com/library/index.php'>login</a> to CHRP Media Library</div>";

			mail($mail, $subject, $body, $headers);
			header("Location:index.php");
		}
	}
	else
	{
		header("Location:forgot.php?mode=invalid");
	}
}
else
{
	header("Location:forgot.php?mode=fill");
}
?>