<?php
require_once "connect.php";

$qry = "CREATE TABLE images(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	name VARCHAR(25),
	type VARCHAR(5),
	size VARCHAR(10),
	width INT(4),
	height INT(4),
	date DATE,
	category VARCHAR(15),
	tag VARCHAR(255),
	path VARCHAR(50)
	);";

$result = mysql_query($qry) or die(mysql_error());
echo "Success";
?>