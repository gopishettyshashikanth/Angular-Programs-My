<!DOCTYPE html>
<?php
	include("session.php");
	include("announcementsDesc.php");
	
	$config = parse_ini_file("config.ini");
	$config['url'] = basename($_SERVER['SCRIPT_NAME']);
	$f = fopen("config.ini","w");
	foreach($config as $name => $value)
	{
		fwrite($f, "$name = \"$value\"\n");
	}
	fclose($f);
	
	$ed_stat = "block";
	$dd_stat = "block";
	$view_stat = "block";
	$dt_stat = "block";
	//$userView_stat="block";
	
	if($_SESSION['type'] == "User")
	{
		$ed_stat = "none";
		$dd_stat = "inline";
		$dt_stat = "none";
		$view_stat = "inline";	
		$userView_stat="none";
	}
?>
<html>
<head>
	<meta charset="UTF-8" />
	<title>CHRP Library</title>
	<link rel='stylesheet' href='css/jquery-ui.css' />
    <link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
	<script src="js/jquery.min.js" type="text/javascript"></script>
	<link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" title="prettyPhoto main stylesheet" charset="utf-8" />
	
	<!--Start Here shashi-->
	
	 <!-- Add jQuery library -->
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
<!-- Add mousewheel plugin -->
<script type="text/javascript" src="lib/jquery.mousewheel-3.0.6.pack.js"></script>

<!-- Add fancyBox -->
<link rel="stylesheet" href="source/jquery.fancybox.css?v=2.1.5" type="text/css" media="screen" />
<script type="text/javascript" src="source/jquery.fancybox.pack.js?v=2.1.5"></script>

<!-- Optionally add helpers - button, thumbnail and/or media -->
<link rel="stylesheet" href="source/helpers/jquery.fancybox-buttons.css?v=1.0.5" type="text/css" media="screen" />
<script type="text/javascript" src="source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>
<script type="text/javascript" src="source/helpers/jquery.fancybox-media.js?v=1.0.6"></script>

<link rel="stylesheet" href="source/helpers/jquery.fancybox-thumbs.css?v=1.0.7" type="text/css" media="screen" />
<script type="text/javascript" src="source/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>
<script>
$(".fancybox").fancybox({
    openEffect  : 'none',
    closeEffect : 'none',
	'width'     : '1024',
    'height'    : '720',
    iframe : {
        preload: false
    }
});
</script>
	<!-- End Here -->
	<script src="js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>

	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
		//window.onbeforeunload = function() { return "You work will be lost."; };
	</script>

	<script type="text/javascript" charset="utf-8">
		$(document).ready(function(){
			$("area[rel^='prettyPhoto']").prettyPhoto();
			
			$(".gallery:first a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal',theme:'light_square',slideshow:3000, autoplay_slideshow: true});
			$(".gallery:gt(0) a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'fast',slideshow:10000, hideflash: true});

			$("#custom_content a[rel^='prettyPhoto']:first").prettyPhoto({
				custom_markup: '<div id="map_canvas" style="width:260px; height:265px"></div>',
				changepicturecallback: function(){ initialize(); }
			});

			$("#custom_content a[rel^='prettyPhoto']:last").prettyPhoto({
				custom_markup: '<div id="bsap_1259344" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6"></div><div id="bsap_1237859" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6" style="height:260px"></div><div id="bsap_1251710" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6"></div>',
				changepicturecallback: function(){ _bsap.exec(); }
			});
			
			document.getElementById('img').style.display = 'none';
			document.getElementById('del').style.display = 'none';
		});		
	</script>
	
	<script language="JavaScript" type="text/javascript">
		$(document).ready(function()
		{
			$("a.delete").click(function(e)
			{
				if(!confirm('Confirm Delete File?'))
				{
					e.preventDefault();
					return false;
				}
				return true;
			});
			$("a.update").click(function(e)
			{
				if(!confirm('Confirm Update File?'))
				{
					e.preventDefault();
					return false;
				}
				return true;
			});		
		});
	</script>
</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="">
	<?php		
		$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
		$limit = 20;
		$startpoint = ($page * $limit) - $limit;
		$search = '';
		$category = 'All';
		$statement = '';
		$param = "?keyword=".$search."&category=".$category."&";

		function pagination($query, $per_page, $page = 1, $url = '?')
		{
			$query = "SELECT COUNT(*) as num FROM {$query}";
			$row = mysql_fetch_array(mysql_query($query));
			$total = $row['num'];
			//shashi
			$adjacents = "4";
			
			$page = ($page == 0 ? 1 : $page);
			$start = ($page - 1) * $per_page;
			
			$prev = $page - 1;
			$next = $page + 1;
			$lastpage = ceil($total / $per_page);
			$lpm1 = $lastpage - 1;
			
			$pagination = "";
			if ($lastpage > 1)
			{
				$pagination .= "<ul class='pagination'>";
				$pagination .= "<li class='details'>Page $page of $lastpage</li>";
				if ($lastpage < 4 + ($adjacents * 2))
				{
					for ($counter = 1; $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<li><a class='current'>$counter</a></li>";
						else
							$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
					}
				}
				elseif ($lastpage > 4 + ($adjacents * 2))
				{
					if ($page < 1 + ($adjacents * 2))
					{
						for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
						{
							if ($counter == $page)
								$pagination.= "<li><a class='current'>$counter</a></li>";
							else
								$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
						}
						$pagination.= "<li class='dot'>...</li>";
						$pagination.= "<li><a href='{$url}page=$lpm1'>$lpm1</a></li>";
						$pagination.= "<li><a href='{$url}page=$lastpage'>$lastpage</a></li>";
					}
					elseif ($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
					{
						$pagination.= "<li><a href='{$url}page=1'>1</a></li>";
						$pagination.= "<li><a href='{$url}page=2'>2</a></li>";
						$pagination.= "<li class='dot'>...</li>";
						for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
						{
							if ($counter == $page)
								$pagination.= "<li><a class='current'>$counter</a></li>";
							else
								$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
						}
						$pagination.= "<li class='dot'>..</li>";
						$pagination.= "<li><a href='{$url}page=$lpm1'>$lpm1</a></li>";
						$pagination.= "<li><a href='{$url}page=$lastpage'>$lastpage</a></li>";
					}
					else
					{
						$pagination.= "<li><a href='{$url}page=1'>1</a></li>";
						$pagination.= "<li><a href='{$url}page=2'>2</a></li>";
						$pagination.= "<li class='dot'>..</li>";
						for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
						{
							if ($counter == $page)
								$pagination.= "<li><a class='current'>$counter</a></li>";
							else
								$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
						}
					}
				}
				
				if ($page < $counter - 1)
				{
					$pagination.= "<li><a href='{$url}page=$next'>Next</a></li>";
					$pagination.= "<li><a href='{$url}page=$lastpage'>Last</a></li>";
				}
				else
				{
					$pagination.= "<li><a class='current'>Next</a></li>";
					$pagination.= "<li><a class='current'>Last</a></li>";
				}
				$pagination.= "</ul>\n";
			}
			return $pagination;
		}
	?>
	
<div class="container-fluid">		
				
<form action="" method="Get" class="form-horizontal">	
	<div class="row">	
		<div class="col-sm-6 col-md-6">	
			<div class="form-group">
				 <label class="control-label col-sm-6 col-md-4" for="Search">Search Course:</label>
				<div class="col-sm-6 col-md-8">	
					<input name="keyword" type="text" class="form-control" id="Keyword" placeholder='Search Course' onclick="this.value = '';" value="<?php if (isset($_REQUEST["keyword"])){echo $_REQUEST["keyword"];} ?>" style="height: 30px;"/>
				</div>
			</div>		
		</div>
		
		<div class="col-sm-4 col-md-4">	
			<select class="form-control" name="category">
				<option value="All" selected>All Categories</option>
				<option value="Storyline">Storyline</option>
				<option value="Captivate">Captivate</option>
				<option value="Videos">Videos</option>
				<option value="Pdf">Pdf</option>
				<option value="Pdf">Flash</option>
			</select>
		</div>						
		<div class="col-sm-2 col-md-2">					
			<input type="submit" class="btn btn-primary" name="browse" value="Search" style="height: 30px;" />
		</div>
	</div>	
</form>
</div>

<div class="row">	
	<div class="col-sm-14 col-md-10">	
		<?php
				if (isset($_REQUEST["id"]))
				{
					$statement = "images where name='" . $_REQUEST["id"] . "'";
				}
				else
				{
					$statement = "images";
					
				}
				if(isset($_REQUEST["keyword"]))
				{
					$search=trim($_REQUEST["keyword"]);
					$category = $_REQUEST['category'];
					$words=split(" ",$search);
					$q = "";
					$i = 0;
					while(list($key,$val)=each($words))
					{
						if($val <> " " and strlen($val) > 0)
						{
							if($i==0)
								$q .= " tag LIKE '%$val%'";
							else
								$q .= " or tag LIKE '%$val%'";
							$i++;
						}
					}		
					if(!empty($search))
					{
						if($category == "All")
						{
							$statement = " images where $q ";
						}
						else
						{
							$statement = " images where ($q) and category='$category' ";
						}
					}
					else
					{
						if($category == "All")
						{
							
							$statement = " images ";
						}
						else
						{
							$statement = " images where category='$category' ";
						}
					}
					$param = "?keyword=".$search."&category=".$category."&";
				}
				
				if(!empty($_POST['field']))
				{
					$statement = $sub;				
				}

				$query = mysql_query("SELECT * FROM {$statement} order by name asc LIMIT {$startpoint} , {$limit}");
				$num_rows = mysql_num_rows($query);
 
				$r = 4;
				$j = 0;
				
				$images = ["jpg","jpeg","png","gif"];

				while ($data = mysql_fetch_assoc($query))
				{
					$filename = $data['name'];
					$myFileType = split ("\.", $filename);
					$category = $data['category'];
					$title = "Name : ".$data['name']."<br/>Size : ".$data['size']."<br/>Dimensions : ".$data['width']."x".$data['height'];
					$extension = explode(".",$filename)[1];
					if(!in_array($extension, $images))
						$filename = explode(".",$filename)[0].".jpg";
					if($j == 0)
						echo "<div class='thumbnail'>";
			?>
			<div class="col-sm-3 col-md-3">
				<div class="thumbnail" style="border: 1px solid #ddd;">
					<a class="fancybox" data-fancybox-type="iframe" rel="<?php if($myFileType[1] == "zip")	echo ""; 
					else if($myFileType[1] == "mp4") echo "";  
					else if($myFileType[1] == "pdf") echo "";						
					else echo "prettyPhoto";?>" href="<?php 	

					if($myFileType[1] == "zip"){
							
						if($category == "Captivate"){
									
							/*echo "uploads/" . $category . "/" .$myFileType[0] . "/index_SCORM.html";*/
						}else if($category == "Storyline"){
									
							/*echo "uploads/" . $category . "/" .$myFileType[0] . "/story.html";*/
						}else if($category == "Flash"){
									
							/*echo "uploads/" . $category . "/" .$myFileType[0] . "/course.html";*/
						}							
						}else if($myFileType[1] == "mp4"){	

							//change path to mp4 to videos shashi
						echo "uploads/" . $myFileType[1] . "/" .$myFileType[0] . ".mp4";
						
						//echo "uploads/Videos/" .$myFileType[0] . ".mp4";
						
						}else if($myFileType[1] == "pdf"){							
						echo "uploads/" . $myFileType[1] . "/" .$myFileType[0] . ".pdf";
						
						}							
						 ?>" title="<?php echo $data['name'];?>" name="<?php echo $title;?>">
						<img src="<?php 
						if($category == "Captivate") echo 'images/icons/cptx.png'; 
						else if($category == "Storyline") echo 'images/icons/story.png'; 
						else if($category == "Flash") echo 'images/icons/fla.png'; 
						else if($myFileType[1] == "mp4") echo 'images/icons/mp4.png';  
						else if($myFileType[1] == "zip") echo 'images/icons/zip.png';
						else if($myFileType[1] == "pdf") echo 'images/icons/pdf.png';						
						else echo 'thumbs/' . $filename;?>" width="140px" height="120px" /></a>
					
					<div align="center" style="padding-top:10px; display:<?php echo $view_stat; ?>;">
					<p>
						<a href="edit.php?id=<?php echo $data['id'];?>&mode=" class="links" title="Edit"><img src="images/edit.png" width="40" height="22" style="display:<?php echo $ed_stat; ?>" ></a>
						
						<a href="downloadFile.php?filename=<?php echo $data['name'];?>&username=<?php echo $_SESSION['user'];?> &category=<?php echo $data['category'];?>" class="links" title="Download"><img src="images/download.png" width="40" height="22" style="display:<?php echo $dd_stat;?>" ></a>
						
						<a href="deleteFile.php?filename=<?php echo $data['name'];?>" class="links" title="Delete" onclick="return confirm('Confirm Delete File?');"><img src="images/delete.png" width="40" height="22" style="display:<?php echo $dt_stat; ?>" ></a>
						
						<a class="fancybox" data-fancybox-type="iframe" href="<?php 	

						if($myFileType[1] == "zip"){
							
								if($category == "Captivate"){
									
									/*echo "uploads/" . $category . "/" .$myFileType[0] . "/index_SCORM.html";*/
								}else if($category == "Storyline"){
									
									/* echo "uploads/" . $category . "/" .$myFileType[0] . "/story.html"; */
								}else if($category == "Flash"){
									
									/* echo "uploads/" . $category . "/" .$myFileType[0] . "/course.html"; */
								}					
						}else if($myFileType[1] == "mp4"){	
						echo "uploads/" . $myFileType[1] . "/" .$myFileType[0] . ".mp4";
											
						}else if($myFileType[1] == "pdf"){							
						echo "uploads/" . $myFileType[1] . "/" .$myFileType[0] . ".pdf";
						
						}							
						 ?>"><img src="images/view.png" width="40" height="22" style="display:<?php echo $view_stat; ?>"></a>
						</p>
					</div>
				</div>
			</div>		

			<?php			
				$j++;
				if($j == $r)
				{
					echo "</div>";
					$j = 0;
				}
			}
			?>
	</div>
	
	<div class="col-sm-4 col-md-2" style="margin-top:50px">
			<?php							
				//$sql = "delete FROM announcements";
				$getSql = "SELECT description FROM announcements";
				mysql_select_db('dynapac_library');
				$query = mysql_query($getSql);
			 	
				while($row = mysql_fetch_array($query)) {
					echo "{$row['description']}" ;
				}  				
				?>
	</div>
</div>
	
<div class="row" style="color:#258; text-align:center;">
	<?php
		if ($num_rows > '0')
		{
			echo '<b> Showing ';
			echo $num_rows;
			echo '</b>&nbsp;Records ';
		}
		else
		{
			echo '<b>No Records Found</b>';
		}
	?>
</div>
<br/>
<div class="pagination">
			<?php
				echo pagination($statement, $limit, $page, $param); ?>
</div>
				
<div class="login-help" style="display:<?php 
		 
	echo $userView_stat;		

?>">
<a href="main.php">Back to Main</a>
</div>
		
</body>
</html>