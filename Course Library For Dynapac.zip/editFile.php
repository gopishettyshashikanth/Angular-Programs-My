<?php
require_once "connect.php";

if(isset($_POST["submit"]))
{
	$fname = $_GET['fname'];
	$id = $_GET['id'];
	$ext = $_GET['ext'];
	$images = ["jpg","jpeg","png","gif"];
	
	$name = trim($_POST['name']).".".$ext;
	$cate = trim($_POST['category']);
	$tag = trim($_POST['tag']);
	//echo $name."<br/>".$cate."<br/>".$tag."<br/>".$fname."<br/>".$id."<br/>".$ext;
	
	$num_rows = 0;
	$isImg = true;
	
	if($fname != $name)
	{	
		$qry = "SELECT * FROM images WHERE name='".$name."'";
		$result = mysql_query($qry) or die(mysql_error());
		$num_rows = mysql_num_rows($result);
	}

	if($num_rows == 0)
	{
		$old = "uploads/".$fname;
		$new = "uploads/".$name;
				
		$sql = "UPDATE images SET name='".$name."', category='".$cate."', tag='".$tag."', path='".$new."' WHERE id=".$id;
		$result = mysql_query($sql) or die(mysql_error());
		mysql_close();
		
		rename ($old, $new);
		
		if(!in_array($ext, $images))
		{
			$old1 = "uploads/".explode(".",$fname)[0].".jpg";
			$new1 = "uploads/".trim($_POST['name']).".jpg";
			rename ($old1, $new1);
			$isImg = false;
		}
		
		if($isImg == true)
		{
			$oldThumb = "thumbs/".$fname;
			$newThumb = "thumbs/".$name;
			rename($oldThumb, $newThumb);
		}
		else
		{
			$oldThumb = "thumbs/".explode(".",$fname)[0].".jpg";
			$newThumb = "thumbs/".trim($_POST['name']).".jpg";
			rename($oldThumb, $newThumb);
		}
		
		$url = "edit.php?id=".$id."&mode=success";
		header("Location:".$url);
	}
	else
	{
		$url = "edit.php?id=".$id."&mode=exist";
		header("Location:".$url);
	}
}
?>