<!DOCTYPE html>
<?php
	include "banner.php";
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>CHRP Library</title>
	<link rel='stylesheet' href='css/jquery-ui.css' />
	<link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
		//window.onbeforeunload = function() { return "You work will be lost."; };
	</script>
<!-- Start Alexa Certify Javascript -->
<script type="text/javascript">
_atrk_opts = { atrk_acct:"koxHk1ao6C524B", domain:"chrp-india.com",dynamic: true};
(function() { var as = document.createElement('script'); as.type = 'text/javascript'; as.async = true; as.src = "https://d31qbv1cthcecs.cloudfront.net/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();
</script>
<noscript><img src="https://d5nxst8fruw4z.cloudfront.net/atrk.gif?account=koxHk1ao6C524B" style="display:none" height="1" width="1" alt="" /></noscript>
<!-- End Alexa Certify Javascript -->  



</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="" class="boxed">
	<br/>
	<div class="login-card">
		<h1>Register</h1>
		<form action="addNewUser.php" method="post" id="regForm">
			<input type="text" name="empid" placeholder="Employee ID" maxlength="15" />
			<input type="text" name="username" placeholder="User Name"maxlength="20" />
			<input type="password" name="password" placeholder="Password" maxlength="20" />
			<input type="text" name="mail" placeholder="Email" maxlength="50" />
			<input type="text" name="security" placeholder="Security Text" maxlength="20" />
			<input type="submit" name="Submit" class="login login-submit" value="Submit" />
		</form>
		<div class="login-help">
		<?php
			if(isset($_GET['mode']))
			{
				if($_GET['mode']=='exist')
				{
					echo "<span style=color:red;>Username / eMail is already exist!</span>";
				}
				if($_GET['mode']=='success')
				{
					echo "<span style=color:green;>Registration Successfull!<br/>You will get mail shortly, after the admin approval.</span>";
				}
				if($_GET['mode']=='pleaseFill')
				{
					echo "<span style=color:red;>Please fill all details...</span>";
				}
				if($_GET['mode']=='email')
				{
					echo "<span style=color:red;>Invalid eMail format!</span>";
				}
			}
		?>
		</div>
		</br/>
		<div class="login-help">
			<a href="index.php">Login</a>
		</div>		
	</div>
	
	<!--table width="100%" height="10px" style="position:fixed; left:0px; right:0px; bottom:0px;" border="0" cellpadding="5">
	<tr>
		<td align="center" style="color:#008ed2; font-size:12px;">
			Copyright &copy; CHRP-INDIA Pvt. Ltd., 2014
		</td>
	</tr>
	</table-->
</body>
</html>