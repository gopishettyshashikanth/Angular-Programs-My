<?php
error_reporting(0);
include_once "connect.php";
require_once "createThumbs.php";
date_default_timezone_set('Asia/Kolkata');

$user = $_SESSION['user'];
$dt = date('d M Y h:i a');

if(isset($_POST["Submit"]))
{
	$category = $_POST['category'];
	$cname = $_POST['cname'];
	$cdesc = $_POST['cdesc'];
	$tag = $_POST['tag'];		
	
	$isImage = true;
	$isZip = true;
	$resize = 800;

	if($category != "" && $tag != "")
	{
		$temp = explode(".", $_FILES["files"]["name"]);
		$extension = strtolower(end($temp));

		$file = $_FILES["files"]["tmp_name"];
		$filename = $_FILES["files"]["name"];
		$type = $_FILES["files"]["type"];
		$size = round($_FILES["files"]["size"] / 1024) . " KB";
		//$path = 'uploads/' . $_FILES['files']['name'];
		
		$path = 'uploads/' . $category. '/' . $_FILES['files']['name'];

		list($width, $height, $typeCode, $attr) = getimagesize($file);
		
		$str_explode=explode(".",$filename);

		echo $path."<br/>";
				
		if ($_FILES["files"]["error"] > 0)
		{
			echo "Return Code: " . $_FILES["files"]["error"] . "<br>";
			header("Location:upload.php?mode=".$_FILES["files"]["error"]);
		}
		else
		{
			if (file_exists("uploads/" . $_FILES["files"]["name"]))
			{
			  header("Location:upload.php?mode=exist");
			}
			else if (file_exists("uploads/mp4/" . $_FILES["files"]["name"]))
			{
			  header("Location:upload.php?mode=exist");
			}
			else if (file_exists("uploads/Flash/" . $_FILES["files"]["name"]))
			{
			  header("Location:upload.php?mode=exist");
			}
			else if (file_exists("uploads/Captivate/" . $_FILES["files"]["name"]))
			{
			  header("Location:upload.php?mode=exist");
			}
			else if (file_exists("uploads/Storyline/" . $_FILES["files"]["name"]))
			{
			  header("Location:upload.php?mode=exist");
			}
			else if (file_exists("uploads/Pdf/" . $_FILES["files"]["name"]))
			{
			  header("Location:upload.php?mode=exist");
			}
			else
			{
				$sql = "INSERT INTO images (name, type, size, width, height, date, category, cname, cdesc,tag, path) VALUES ('$filename', '$type', '$size', '$width', '$height', '".date("Y-m-d")."', '$category', '$cname', '$cdesc', '$tag', '$path')";
				
				//$sql = "INSERT INTO images (name, type, size, width, height, date, category, tag, path) VALUES ('$filename', '$type', '$size', '$width', '$height', '".date("Y-m-d")."', '$category', '$tag', '$path')";
				
				
				$query = mysql_query($sql) or die(mysql_error());
					
					//file upload code
										
					if($str_explode[1] == "zip"){					
																	
						if($category == "Captivate"){
							move_uploaded_file($_FILES["files"]["tmp_name"], "uploads/Captivate/" . $_FILES["files"]["name"]);
						}else if($category == "Storyline"){
							move_uploaded_file($_FILES["files"]["tmp_name"], "uploads/Storyline/" . $_FILES["files"]["name"]);
						} else if($category == "Videos"){
							header("Location:upload.php?mode=incorrect");
						}
						
			if($_FILES["filesNew"]["tmp_name"] != null)
				{
				move_uploaded_file($_FILES["filesNew"]["tmp_name"], "uploads/" . $_FILES["filesNew"]["name"]);
				$isImage = false;
				$isZip = false;
				}	
						
			if($_FILES["files"]["tmp_name"] != null)
				{							
					move_uploaded_file($_FILES["files"]["tmp_name"], "uploads/" . $category . "/" . $_FILES["files"]["name"]);
					$isImage = false;
					$isZip = false;
					$file = 'uploads/' . $category. '/' . $_FILES["files"]["name"];
								
					// get the absolute path to $file
					$path = pathinfo(realpath($file), PATHINFO_DIRNAME);
					$path = $path;																	
					$zipFileName =$_FILES["filesNew"]["name"];
					$zipFileExtension = basename($zipFileName, ".jpg");
																	
					$zip = new ZipArchive;
					$res = $zip->open($file);		
													
					//$zip->extractTo($path);
													
					$zip->extractTo("uploads/" . $category. "/" .$zipFileExtension);
					
					//$zip->archive("uploads/" . $category. "/" . $zipFileExtension);
							
					$zip->close();
					unlink($file);		
				}  
			}
						
					if($str_explode[1] == "mp4"){
						move_uploaded_file($_FILES["files"]["tmp_name"], "uploads/mp4/" . $_FILES["files"]["name"]);
					} else if($str_explode[1] == "zip"){			
							header("Location:upload.php?mode=incorrect");								
						} 
						
					if($str_explode[1] == "pdf"){
						//$isImage == true;
						move_uploaded_file($_FILES["files"]["tmp_name"], "uploads/Pdf/" . $_FILES["files"]["name"]);
					}		
							
				if($isImage == true)
					createThumbs($_FILES['files']['name'],"uploads/","thumbs/",$resize);
				else
					createThumbs($_FILES['filesNew']['name'],"uploads/","thumbs/",$resize);
					
				  $url = json_decode(file_get_contents("http://api.ipinfodb.com/v3/ip-city/?key=2b3d7d0ad1a285279139487ce77f3f58d980eea9546b5ccc5d08f5ee62ce7471&ip=".$_SERVER['REMOTE_ADDR']."&format=json"));
				$loc = $url->ipAddress.",".$url->cityName.",".$url->countryName;

				header("Location:upload.php?mode=success"); 
			}
		}
	}
	else
	{
		header("Location:upload.php?mode=fill");
	}
	
}
?>