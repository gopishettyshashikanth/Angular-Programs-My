(function(){
    'use strict'
    var app = angular.module("login",["ui.router","home","register"])
			.controller("loginCtrl",function($scope,$state){
				

			$scope.loginFun = function () {
                   				
						if($scope.userDetails.email ==="a@a.com" && $scope.userDetails.password ==="abc"){
										
							$state.go('home');
							
						}else{						
	
							$scope.errorMsg = "Username and password in incorrect";
						}
                };	


			$scope.signupFun = function(){
				console.log("register");
				$state.go('register');
			}			
	});		
})();


