(function(){
	
	angular.module("components",[])
		   .filter("modelFilter",[function(){
				return function(Mdata, filteringMCriteria){
					
				
			}			
		}]);
})();