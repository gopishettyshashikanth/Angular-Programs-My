(function(){
    angular.module("components")
		.directive("customDatepicker",[function(){
			return  {
				restrict : "A",
				link:function(scope,elements,attrs){
					
					var config ={};
					if(attrs["changemonth"]){
					config.changeMonth = attrs["changemonth"];
					}
					if(attrs["changeyear"]){
					config.changeYear = attrs["changeyear"];
					}	

					if(attrs['mindate']){
                    config.minDate=attrs["mindate"]
					}
					if(attrs['maxdate']){
                    config.maxDate=attrs["maxdate"]
					}
					
					elements.datepicker(config);
					console.log(config);		
				}
			}
		}])	 
})();