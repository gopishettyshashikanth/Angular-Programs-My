(function(){
	
	angular.module("vehicle")
	
			.service("vehicleSvc",["$http",function($http){
				
				this.getVehicle = function(){
				
				return $http.get("app/api/vehicles.json");
				
				}			
			}]);
})();