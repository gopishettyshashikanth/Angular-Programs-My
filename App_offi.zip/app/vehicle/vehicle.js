(function(){
	
	angular.module("vehicle",[]);

})();