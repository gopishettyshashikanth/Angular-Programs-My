(function(){
    'use strict'
    //code goes here.
    angular.module("register",[]);
})();