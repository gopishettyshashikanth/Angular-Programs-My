(function(){
	
	angular.module("register")
	
			.service("registerSvc",["$http",function($http){
				
				this.getCountries = function(){
				
				return $http.get("app/api/countryList.json")
				
				}

				this.getStates = function(){
					
					return $http.get("app/api/statesList.json")
				}
				
			}]);
})();