(function () {
    'use strict'
    //code goes here.
    angular.module("register")
        .controller("registerCtrl",["$scope","registerSvc",
            function ($scope,registerSvc) {
                $scope.userDetails = {
                    terms: false
                };
               /* $scope.countries = [{
                        "key": "IN",
                        "value": "India"
                    },
                    {
                        "key": "US",
                        "value": "United States"
                    }];
        
                var states = [{
                        "countryCode": "IN",
                        "key": "TG",
                        "value": "Telangana"
                    },
                    {
                        "countryCode": "IN",
                        "key": "AP",
                        "value": "Andhra Pradesh"
                    },
                    {
                        "countryCode": "US",
                        "key": "TX",
                        "value": "Texas"
                    }, {
                        "countryCode": "US",
                        "key": "NY",
                        "value": "New York"
                    }];
        
          $scope.states = [{
                        "countryCode": "IN",
                        "key": "TG",
                        "value": "Telangana"
                    },
                    {
                        "countryCode": "IN",
                        "key": "AP",
                        "value": "Andhra Pradesh"
                    },
                    {
                        "countryCode": "US",
                        "key": "TX",
                        "value": "Texas"
                    }, {
                        "countryCode": "US",
                        "key": "NY",
                        "value": "New York"
                    }];*/
										
					registerSvc.getCountries()					
					.then(function(response){
					$scope.countries = response.data.countries;
					})
					.catch(function(response){
						$scope.showError = response;
					})
										
					registerSvc.getStates()					
					.then(function(response){
					$scope.states = response.data.states;
					})
					.catch(function(response){
						$scope.showError = response;
					})
																
			$scope.loadStates = function(){
				
				$scope.stateLists=[]; 
				angular.forEach($scope.states,function(item){
				
				if(item.countryCode===$scope.selectedCountry.code){
					$scope.stateLists.push(item); 
                }
				
				})
			}	
				
      /*  $scope.loadStates=function(){
                        
            $scope.stateList=[]; angular.forEach(states,function(item){
                if(item.countryCode===$scope.selectedCountry.key){
                   $scope.stateList.push(item); 
                }
            });
            //console.log($scope.stateList);
        };*/

                $scope.registerUser = function () {
                   // console.log($scope.userDetails)
					
                };
            }]);
})();
