(function(){
    
    angular.module("vehicles")
           .controller("vehicleCtrl",["$scope","vehicleSvc",
                                      function($scope,vehicleSvc){
                                                                            
                                          
        $scope.filterRange = [
            {
            range : "between 100000 to 300000",
            min: 100000,
            max: 300000
            },
            {
            range : "between 300000 to 500000",
            min: 300000,
            max: 500000
            },
            {
            range : "between 500000 to 1000000",
            min: 500000,
            max: 1000000
            },
            {
            range : "between 1000000 to 10000000",
            min: 1000000,
            max: 10000000
            }
            
        ]                                                                    
                                          
        vehicleSvc.getVehicleDetails()
        .then(function(response){
            
            $scope.vehicles = response.data.vehicles;
        })
        .catch(function(response){
            
            $scope.showError = response;
            
        });
                                                                            
                                          
    }]);    
})()

