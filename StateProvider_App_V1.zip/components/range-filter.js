(function(){

angular.module("components",[])
        .filter("rangeFilter",[function(){
            
                return function(data, filterCriteria){
                    
                    var newArray = [];
                   
                if(filterCriteria && filterCriteria.min && filterCriteria.max){  
                    
                    _.each(data, function(item){
                        
                        if(item.Price >= filterCriteria.min && item.Price <= filterCriteria.max){
                            
                            
                            newArray.push(item);
                            
                        }
                        
                    });
                    
                    return newArray;
                    
                }else{
                    
                    return data;
                    
                }
                    
                    
                }    
            
            
            
        }])
    
    
    
    

})()