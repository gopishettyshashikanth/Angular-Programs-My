/*angular.module("components")
    .directive("customDatepicker",[function(){
        return {
            restrict:"A",
            link:function(scope,element,attrs){
                
                var config ={};
                if(attrs['mindate']){
                    config.minDate=attrs["mindate"]
                }
                 if(attrs['maxdate']){
                    config.maxDate=attrs["maxdate"]
                }
                element.datepicker(config);
                console.log(attrs['mindate']);
            }
        }
        
    }]);*/

angular.module("components")
       .directive("customDatepicker",[function(){
        return {
            restrict:"A",
            link:function(scope,element,attrs){
                
               // var dateConfig ={};
                var config ={};
                if(attrs['mindate']){
                    config.minDate=attrs["mindate"]
                }
                 if(attrs['maxdate']){
                    config.maxDate=attrs["maxdate"]
                }
                  
                
                if(attrs['changemonth']){
                    config.changeMonth=attrs["changemonth"]
                }
                if(attrs['changeyear']){
                    config.changeYear=attrs["changeyear"]
                }
                element.datepicker(config);                
            }
        }
        
    }]);

