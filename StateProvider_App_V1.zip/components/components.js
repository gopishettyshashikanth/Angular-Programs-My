(function(){
    
    angular.module("components",[]);
    
    
})()