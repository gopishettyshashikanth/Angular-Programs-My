(function(){
    
    angular.module("login",["ui.router","home"])
            .controller("loginCtrl",function($scope,$state){
            
                $scope.loginUser = function(){
                        
                    console.log($scope.userDetails.userName);
                    
                    if($scope.userDetails.userName === "shashi" && $scope.userDetails.password === "shashi"){
                        
                        console.log("correct");
                        $state.go('home');
                        
                    }else{
                        
                        console.log("Incorrect");    
                        $scope.errorMsg="Login not correct";                    
    
                    }  
                } 
            });    
})();