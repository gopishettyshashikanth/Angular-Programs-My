(function(){
    
    angular.module("login",[]);
    
    
    
})()