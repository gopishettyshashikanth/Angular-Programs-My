(function(){
    
    angular.module("vehicleDetails",["register","login","ui.router","lookup","vehicles","components","home"]);
    console.log("module initialization");
    
    angular.module("vehicleDetails")
           .config(["$stateProvider",function($stateProvider){
                
            var homeObj = {
                
                templateUrl : "templates/home.html",
                controller  : "homeCtrl"
            }   
            var vehicleObj = {
                
                templateUrl : "templates/vehicle.html",
                controller  : "vehicleCtrl"
                
            }
            var loginObj = {
                
                templateUrl : "templates/login.html"
                
            }
            var registerObj = {
                templateUrl : "templates/register.html"   
            }
                     
           $stateProvider.state("home",homeObj);
           $stateProvider.state("vehicle",vehicleObj);       
           $stateProvider.state("login",loginObj);       
           $stateProvider.state("register",registerObj);       
    }])    
})()