(function(){
	
	angular.module("student",[]);

})();