(function () {
    angular.module("lookup", []);
})();
