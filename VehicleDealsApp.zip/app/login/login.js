

(function(){
    'use strict'
    angular.module("login",[]);
    
    //config function.
     angular.module("login")
     .config([function(){
         console.log("I am the login Module"); 
     }]);
})();
