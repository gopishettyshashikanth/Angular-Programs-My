(function(){
    
    angular.module("vehicleDetails",["ngRoute","register","login","lookup","vehicles","components","home","angularUtils.directives.dirPagination","student"])
        
    /*angular.module("vehicleDetails",['ngRoute','home','register','vehicles','login'])*/
           .config(['$routeProvider',function($routeProvider){
            
            $routeProvider.when('/', {
				templateUrl : 'templates/login.html',
				controller  : 'loginCtrl'
			})
			.when('/vehicle', {
				templateUrl : 'templates/vehicle.html',
				controller  : 'vehicleCtrl'
			})
			.when('/login', {
				templateUrl : 'templates/login.html',
				controller  : 'loginCtrl'
			})
            .when('/register', {
				templateUrl : 'templates/register.html',
				controller  : 'registerCtrl'
			})
            .when('/home', {
				templateUrl : 'templates/home.html',
				controller  : 'homeCtrl'
			})
			.when('/student', {
				templateUrl : 'templates/student.html',
				controller  : 'studentCtrl'
			});			
    }]);	
    
   /* app.controller('homeCtrl', function($scope) {
		// create a message to display in our view
		$scope.message = 'Everyone come and see how good I look!';
	});*/
    
})();

