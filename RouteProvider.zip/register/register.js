(function(){
    
    angular.module("register",[]);
    
    
})()