<?php
// ensure $dir ends with a slash

/*$dir = "myzips/";

function delTree($dir) {
    $files = glob( $dir . '*', GLOB_MARK );
    foreach( $files as $file ){
        if( substr( $file, -1 ) == '/' )
            delTree( $file );
        else
            unlink( $file );
    }
    rmdir( $dir );
}*/

/*$path = "myzips";
if(!rmdir($path))
  {
  echo ("Could not remove $path");
  }*/
  

// Specify the target directory and add forward slash
/*$dir = "myzips/"; 
// Open the directory
$dirHandle = opendir($dir); 
// Loop over all of the files in the folder
while ($file = readdir($dirHandle)) { 
    // If $file is NOT a directory remove it
    if(!is_dir($file)) { 
        unlink ("$dir"."$file"); // unlink() deletes the files
    }
}
// Close the directory
closedir($dirHandle); */

$dir = "myzips/";

/*function deleteAll($path)
{
    $dir = dir($path);

    while ($file = $dir->read())
    {
        if ($file == '.' || $file == '..') continue;

        $file = $path . '/' . $file;

        if (is_dir($file))
        {
            deleteAll($file);
            rmdir($file);
        }
        else
        {
            unlink($file);
        }
    }
}

deleteAll($dir);*/

$dirname = "myzips";

function delete_directory($dirname) {
         if (is_dir($dirname))
           $dir_handle = opendir($dirname);
	 if (!$dir_handle)
	      return false;
	 while($file = readdir($dir_handle)) {
	       if ($file != "." && $file != "..") {
	            if (!is_dir($dirname."/".$file))
	                 unlink($dirname."/".$file);
	            else
	                 delete_directory($dirname.'/'.$file);
	       }
	 }
	 closedir($dir_handle);
	 rmdir($dirname);
	 return true;
}

delete_directory($dirname)

?>