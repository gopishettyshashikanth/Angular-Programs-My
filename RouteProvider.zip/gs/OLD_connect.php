<?php
ob_start();
session_start();
header("Expires: 0");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("cache-control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
$db_host = "localhost";
$db_username = "chrpind_dbuser";
$db_password = "chrpindia2014!";
$db_name = "chrpind_library";
//$pipaddress = getenv(HTTP_X_FORWARDED_FOR);
//$ipaddress = getenv(REMOTE_ADDR);
$conn = mysql_connect($db_host, $db_username, $db_password);
if ($conn) {
    mysql_select_db($db_name);
}
?>