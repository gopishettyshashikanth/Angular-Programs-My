<!DOCTYPE html>
<?php
	include("session.php");
	$config = parse_ini_file("config.ini");
	$config['url'] = basename($_SERVER['SCRIPT_NAME']);
	$f = fopen("config.ini","w");
	foreach($config as $name => $value)
	{
		fwrite($f, "$name = \"$value\"\n");
	}
	fclose($f);
?>
<html>
<head>
	<meta charset="UTF-8" />
	<title>CHRP Library</title>
	<link rel='stylesheet' href='css/jquery-ui.css' />
    <link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
	<script src="js/jquery-1.11.1.min.js"></script>
	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
		//window.onbeforeunload = function() { return "You work will be lost."; };
	</script>
	
	<script language="JavaScript" type="text/javascript">
		var data = [];
		var path = "";
		function updateData(m,n,s)
		{
			data[m-1][n] = s; 
			//alert(data);
		}
		function getPath(m)
		{
			return path = "updateUser.php?t="+data[m-1][0]+"&m="+data[m-1][1]+"&s="+data[m-1][2];
		}
		
		$(document).ready(function()
		{
			$("a.delete").click(function(e)
			{
				if(!confirm('Confirm Delete Account?'))
				{
					e.preventDefault();
					return false;
				}
				return true;
			});
			$("a.update").click(function(e)
			{
				if(!confirm('Confirm Update Account?'))
				{
					e.preventDefault();
					return false;
				}
				return true;
			});		
		});
	</script>
	<style>
		img
		{
			border : 0;
		}
	</style>

</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="">
	<?php
		$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
		$limit = 10;
		$startpoint = ($page * $limit) - $limit;

		function pagination($query, $per_page = 10, $page = 1, $url = '?')
		{
			$query = "SELECT COUNT(*) as num FROM {$query}";
			$row = mysql_fetch_array(mysql_query($query));
			$total = $row['num'];
			$adjacents = "4";
			
			$page = ($page == 0 ? 1 : $page);
			$start = ($page - 1) * $per_page;
			
			$prev = $page - 1;
			$next = $page + 1;
			$lastpage = ceil($total / $per_page);
			$lpm1 = $lastpage - 1;
			
			$pagination = "";
			if ($lastpage > 1)
			{
				$pagination .= "<ul class='pagination'>";
				$pagination .= "<li class='details'>Page $page of $lastpage</li>";
				if ($lastpage < 7 + ($adjacents * 2))
				{
					for ($counter = 1; $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<li><a class='current'>$counter</a></li>";
						else
							$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
					}
				}
				elseif ($lastpage > 5 + ($adjacents * 2))
				{
					if ($page < 1 + ($adjacents * 2))
					{
						for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
						{
							if ($counter == $page)
								$pagination.= "<li><a class='current'>$counter</a></li>";
							else
								$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
						}
						$pagination.= "<li class='dot'>...</li>";
						$pagination.= "<li><a href='{$url}page=$lpm1'>$lpm1</a></li>";
						$pagination.= "<li><a href='{$url}page=$lastpage'>$lastpage</a></li>";
					}
					elseif ($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
					{
						$pagination.= "<li><a href='{$url}page=1'>1</a></li>";
						$pagination.= "<li><a href='{$url}page=2'>2</a></li>";
						$pagination.= "<li class='dot'>...</li>";
						for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
						{
							if ($counter == $page)
								$pagination.= "<li><a class='current'>$counter</a></li>";
							else
								$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
						}
						$pagination.= "<li class='dot'>..</li>";
						$pagination.= "<li><a href='{$url}page=$lpm1'>$lpm1</a></li>";
						$pagination.= "<li><a href='{$url}page=$lastpage'>$lastpage</a></li>";
					}
					else
					{
						$pagination.= "<li><a href='{$url}page=1'>1</a></li>";
						$pagination.= "<li><a href='{$url}page=2'>2</a></li>";
						$pagination.= "<li class='dot'>..</li>";
						for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
						{
							if ($counter == $page)
								$pagination.= "<li><a class='current'>$counter</a></li>";
							else
								$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
						}
					}
				}
				
				if ($page < $counter - 1)
				{
					$pagination.= "<li><a href='{$url}page=$next'>Next</a></li>";
					$pagination.= "<li><a href='{$url}page=$lastpage'>Last</a></li>";
				}
				else
				{
					$pagination.= "<li><a class='current'>Next</a></li>";
					$pagination.= "<li><a class='current'>Last</a></li>";
				}
				$pagination.= "</ul>\n";
			}
			return $pagination;
		}
	?>
	
	<div class="search-card">
		<h1>User Accounts</h1>
		<div align="center"></div>
		<table width="1000" border="0" style="margin: auto;">
			<tr style="background:#aaa; color:#000;">
				<th width="30px">SNo</th><th width="50px">Photo</th><th width="130px">Emp_ID</th><th>Name</th><th width="100px">Type</th><th width="250px">eMail</th><th width="100px">Status</th><th width="60px">Update</th><th width="50px">Delete</th>
			</tr>
			<?php
				if (isset($_REQUEST["id"]))
				{
					$statement = "images where name='" . $_REQUEST["id"] . "'";
				}
				else
				{
					$statement = "users";
				}
				if(isset($_REQUEST["keyword"]))
				{
					$search=trim($_REQUEST["keyword"]);
					//$limit="10";
					$category = $_REQUEST['category'];
					
					$words=split(" ",$search);
					$q = "";
					$i = 0;
					while(list($key,$val)=each($words))
					{
						if($val <> " " and strlen($val) > 0)
						{
							if($i==0)
								$q .= " tag LIKE '%$val%'";
							else
								$q .= " and tag LIKE '%$val%'";
							$i++;
						}
					}
					if(!empty($search))
					{
					if($category == "All")
					{
						$statement = " images where $q ";
					}
					else
					{
						$statement = " images where ($q) and category='$category' ";
					}
					}
				}
				
				$query = mysql_query("SELECT * FROM {$statement} order by username asc LIMIT {$startpoint} , {$limit}");
				//echo $statement;
				$num_rows = mysql_num_rows($query);
				$i = 0;
				while ($data = mysql_fetch_assoc($query))
				{	
					echo "<script type='text/javascript'>
						data[".$i."] = [];
						data[".$i."][0] = '".$data['type']."';
						data[".$i."][1] = '".$data['mail']."';
						data[".$i."][2] = '".$data['status']."';
						</script>";
					$i++;
					$sn = $i+$limit*($page-1);
			?>
			<tr align="center" style="background:#ddd; color:#000; line-height:40px">
				<td><?php echo $sn;?></td>
				<td><img src="images/human.png" width="40px" height="40px" style="vertical-align:middle"/></td>
				<td><?php echo $data['emp_id']?></td>
				<td><?php echo $data['username']?></td>
				<td>
				<select name="userType" style="height:30px;" onchange="updateData(<?php echo $i;?>,0,this.value);">
					<option value="Admin" <?php if($data['type']=="Admin") echo 'selected'?>>Admin</option>
					<option value="Manager" <?php if($data['type']=="Manager") echo 'selected'?>>Manager</option>
					<option value="User" <?php if($data['type']=="User") echo 'selected'?>>User</option>
				</select>
				</td>
				<td><?php echo $data['mail']?></td>
				<td>
				<select name="userStatus" style="height:30px;" onchange="updateData(<?php echo $i;?>,2,this.value);">
					<option value="Pending" <?php if($data['status']=="Pending") echo 'selected'?>>Pending</option>
					<option value="Approve" <?php if($data['status']=="Approve") echo 'selected'?>>Approve</option>
					<option value="Block" <?php if($data['status']=="Block") echo 'selected'?>>Block</option>
				</select>
				</td>
				<td><a href="#" onclick="this.href=getPath(<?php echo $i;?>);"><img src="images/update.png" width="30px" height="30px" style="vertical-align:middle"></a></td>
				<td><a href="deleteUser.php?mail=<?php echo $data['mail']?>" class="delete"><img src="images/dt.png" width="30px" height="30px" style="vertical-align:middle"></a></td>
			</tr>
			<?php
				}
			?>
		</table>

		<div style="color:#258; text-align:center;">
			<?php
				if ($num_rows > '0')
				{
					echo '<b> Showing ';
					echo $num_rows;
					echo '</b>&nbsp;Records ';
				}
				else
				{
					echo '<b>No Records Found</b>';
				}
			?>
		</div>
		<br/>
		<div class="pagination" style="list-style:none;">
			<?php echo pagination($statement, $limit, $page); ?>
		</div>
		<div class="login-help">
			<a href="main.php">Back to Main</a>
		</div>
	</div>

	<!--table width="100%" height="10px" style="position:fixed; left:0px; right:0px; bottom:0px;" border="0" cellpadding="5">
	<tr>
		<td align="center" style="color:#008ed2; font-size:12px;">
			Copyright &copy; CHRP-INDIA Pvt. Ltd., 2014
		</td>
	</tr>
	</table-->
</body>
</html>