<!DOCTYPE html>
<?php
	include "banner.php";
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>CHRP Library</title>
	<link rel='stylesheet' href='css/jquery-ui.css' />
	<link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
		//window.onbeforeunload = function() { return "You work will be lost."; };
	</script>
</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="">
	<br/>
	<div class="login-card">
		<h1>Forgot Password</h1>
		<form action="checkUser.php" method="post">
			<input type="text" name="mail" placeholder="Email" />
			<input type="text" name="security" placeholder="Security Text" />
			<br/>
			<input type="submit" name="submit" class="login login-submit" value="Submit" onclick="this.value='submitting, please wait...';"/>
		</form>
		<div class="login-help">
		<?php
		if(isset($_GET['mode']))
		{
			if($_GET['mode']=='invalid')
			{
				echo "<span style=color:red;>Invalid eMail/SecurityText...</span>";
			}
			if($_GET['mode']=='fill')
			{
				echo "<span style=color:red;>Please fill all details...</span>";
			}
		}
		?>
		</div>
		<br/>
		<div class="login-help">
			<a href="index.php">Login</a> 
		</div>
	</div>	
</body>
</html>