<!DOCTYPE html>
<?php
	include("session.php");
	$config = parse_ini_file("config.ini");
	$config['url'] = basename($_SERVER['SCRIPT_NAME']);
	$f = fopen("config.ini","w");
	foreach($config as $name => $value)
	{
		fwrite($f, "$name = \"$value\"\n");
	}
	fclose($f);
?>
<html>
<head>
	<meta charset="UTF-8" />
	<title>CHRP Library</title>
    <link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
	
	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
		//window.onbeforeunload = function() { return "You work will be lost."; };

		function hide()
		{
			document.getElementById("printObj").style.display = "none";
			document.getElementById("headObj").style.display = "none";
			document.getElementById("textObj").style.display = "none";
		}
		
		function printTable()
        {
            var printContent = document.getElementById("printableArea");
			document.getElementById("searchObj").style.visibility = 'hidden'; 
            var windowUrl = 'about:blank';
            var uniqueName = new Date();
            var windowName = 'Report' + uniqueName.getTime();
            var printWindow = window.open('', windowName, "left=5000,top=5000,width=5000,height=5000");
            var cssReference = printWindow.document.createElement("link");
            cssReference.href = "css/style.css";
            cssReference.rel = "stylesheet";
            cssReference.type = "text/css";
			
			printWindow.document.write("<h1 style='font-family:verdana,serif; font-weight:lighter; color:#258; text-align:center; font-size:30px;'>CHRP Library Report</h1>");
            printWindow.document.write(printContent.outerHTML);
            printWindow.document.getElementsByTagName('head')[0].appendChild(cssReference);

            printWindow.document.close();
            printWindow.focus();
            printWindow.print();
            printWindow.close();
			document.getElementById("searchObj").style.visibility = 'initial'; 
        }
	</script>
</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="">
	<?php
		$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
		$limit = 10;
		$startpoint = ($page * $limit) - $limit;

		$userName = '';
		$actionType = '';
		$statement = '';
		$param = "?userName=".$userName."&actionType=".$actionType."&";
		
		function pagination($query, $per_page = 10, $page = 1, $url = '?')
		{
			$query = "SELECT COUNT(*) as num FROM {$query}";
			$row = mysql_fetch_array(mysql_query($query));
			$total = $row['num'];
			$adjacents = "4";
			
			$page = ($page == 0 ? 1 : $page);
			$start = ($page - 1) * $per_page;
			
			$prev = $page - 1;
			$next = $page + 1;
			$lastpage = ceil($total / $per_page);
			$lpm1 = $lastpage - 1;
			
			$pagination = "";
			if ($lastpage > 1)
			{
				$pagination .= "<ul class='pagination'>";
				$pagination .= "<li class='details'>Page $page of $lastpage</li>";
				if ($lastpage < 7 + ($adjacents * 2))
				{
					for ($counter = 1; $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<li><a class='current'>$counter</a></li>";
						else
							$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
					}
				}
				elseif ($lastpage > 5 + ($adjacents * 2))
				{
					if ($page < 1 + ($adjacents * 2))
					{
						for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
						{
							if ($counter == $page)
								$pagination.= "<li><a class='current'>$counter</a></li>";
							else
								$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
						}
						$pagination.= "<li class='dot'>...</li>";
						$pagination.= "<li><a href='{$url}page=$lpm1'>$lpm1</a></li>";
						$pagination.= "<li><a href='{$url}page=$lastpage'>$lastpage</a></li>";
					}
					elseif ($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
					{
						$pagination.= "<li><a href='{$url}page=1'>1</a></li>";
						$pagination.= "<li><a href='{$url}page=2'>2</a></li>";
						$pagination.= "<li class='dot'>...</li>";
						for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
						{
							if ($counter == $page)
								$pagination.= "<li><a class='current'>$counter</a></li>";
							else
								$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
						}
						$pagination.= "<li class='dot'>..</li>";
						$pagination.= "<li><a href='{$url}page=$lpm1'>$lpm1</a></li>";
						$pagination.= "<li><a href='{$url}page=$lastpage'>$lastpage</a></li>";
					}
					else
					{
						$pagination.= "<li><a href='{$url}page=1'>1</a></li>";
						$pagination.= "<li><a href='{$url}page=2'>2</a></li>";
						$pagination.= "<li class='dot'>..</li>";
						for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
						{
							if ($counter == $page)
								$pagination.= "<li><a class='current'>$counter</a></li>";
							else
								$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
						}
					}
				}
				
				if ($page < $counter - 1)
				{
					$pagination.= "<li><a href='{$url}page=$next'>Next</a></li>";
					$pagination.= "<li><a href='{$url}page=$lastpage'>Last</a></li>";
				}
				else
				{
					$pagination.= "<li><a class='current'>Next</a></li>";
					$pagination.= "<li><a class='current'>Last</a></li>";
				}
				$pagination.= "</ul>\n";
			}
			return $pagination;
		}
	?>
	
	<div class="search-card">
		<h1>Report</h1>
		<form action="report.php" method="post">		
		<table width="1000px" border="0" style="margin: auto;" id="printableArea">
			<tr>
				<th colspan="5" align="center" id="searchObj">User Name&nbsp;
					<select name="userName" style="height:25px; width:150px;" id="userList">
					<?php
					$sql = mysql_query("SELECT username FROM users");
					while ($row = mysql_fetch_array($sql))
					{
						echo "<option value='".$row['username']."'>".$row['username']."</option>";
					}
					?>
					</select>
					&nbsp;&nbsp;&nbsp;Type&nbsp;
					<select name="actionType" style="height:25px;" id="actionList">
						<option value="All" selected>All</option>
						<option value="Upload">Upload</option>
						<option value="Download">Download</option>
					</select>
					&nbsp;&nbsp;&nbsp;
					<input type="submit" name="submit" value="Submit" style="height:25px;"/>
				</th>
				<th align="right">
					<input type="button" onclick="printTable();" class="print_button" id="printObj"/>
				</th>
			</tr>
			<tr style="background:#aaa; color:#000;" id="headObj">
				<th width="40px">SNo</th><th width="160px">User Name</th><th>Location</th><th width="80px">Type</th><th width="220px">File Name</th><th width='170px'>Date & Time (IST)</th>
			</tr>
			<?php
				$statement = "report where id='0'";
				if(isset($_REQUEST["userName"]))
				{
					$userName = $_REQUEST["userName"];					
					$actionType = $_REQUEST['actionType'];
					
					if($actionType == "All")
					{
						$statement = " report where username='$userName' ";
					}
					else
					{
						$statement = " report where username='$userName' and type='$actionType' ";
					}
					
					$param = "?userName=".$userName."&actionType=".$actionType."&";
					if(empty($userName)) $statement = "report";
				}

				
				$query = mysql_query("SELECT * FROM {$statement} order by id asc LIMIT {$startpoint} , {$limit}");
				//echo $statement;
				$num_rows = mysql_num_rows($query);
				$i = 0;
				while ($data = mysql_fetch_assoc($query))
				{
					$i++;
					$sn = $i+$limit*($page-1);
			?>
			<tr align="center" style="background:#ddd; color:#000; line-height:40px">
				<!--td><?php echo $data['id'];?></td-->
				<td><?php echo $sn;?></td>
				<td><?php echo $data['username'];?></td>
				<td><?php echo $data['location'];?></td>
				<td><?php echo $data['type'];?></td>
				<td><?php echo $data['filename'];?></td>
				<td><?php echo $data['time_date'];?></td>
			</tr>
			<?php
				}
			?>
		</table>
		</form>

		<div style="color:#258; text-align:center;" id="textObj">
			<?php
				if ($num_rows > '0')
				{
					echo '<b> Showing ';
					echo $num_rows;
					echo '</b>&nbsp;Records ';
				}
				else
				{
					echo '<b>No Records Found</b>';
				}
			?>
		</div>
		<br/>
		<div class="pagination" style="list-style:none;">
			<?php echo pagination($statement, $limit, $page, $param); ?>
		</div>
		<div class="login-help">
			<a href="main.php">Back to Main</a>
		</div>
	</div>
	<?php
		if($userName == "")
		{
			echo "<script> hide(); </script>";
		}
		else
		{
			echo "<script> document.getElementById('userList').value = '".$userName."';
			document.getElementById('actionList').value = '".$actionType."'; </script>";
		}
	?>

	<!--table width="100%" height="10px" style="position:fixed; left:0px; right:0px; bottom:0px;" border="0" cellpadding="5">
	<tr>
		<td align="center" style="color:#008ed2; font-size:12px;">
			Copyright &copy; CHRP-INDIA Pvt. Ltd., 2014
		</td>
	</tr>
	</table-->
</body>
</html>