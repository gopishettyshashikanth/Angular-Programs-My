<!DOCTYPE html>
<?php
	include("session.php");
	
	$config = parse_ini_file("config.ini");
	$config['url'] = basename($_SERVER['SCRIPT_NAME']);
	$f = fopen("config.ini","w");
	foreach($config as $name => $value)
	{
		fwrite($f, "$name = \"$value\"\n");
	}
	fclose($f);
	
	$ed_stat = "block";
	$dd_stat = "block";
	$view_stat = "block";
	$dt_stat = "block";
	if($_SESSION['type'] == "User")
	{
		$ed_stat = "none";
		$dd_stat = "none";
		$dt_stat = "none";
		$view_stat = "none";
	}
	else if($_SESSION['type'] == "Manager")
	{
		$view_stat = "block";
		$dt_stat = "none";
	}
?>
<html>
<head>
	<meta charset="UTF-8" />
	<title>CHRP Library</title>
	<link rel='stylesheet' href='css/jquery-ui.css' />
    <link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
	<script src="js/jquery.min.js" type="text/javascript"></script>
	<link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" title="prettyPhoto main stylesheet" charset="utf-8" />
	
	<!--Start Here shashi-->
	
	 <!-- Add jQuery library -->
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
<!-- Add mousewheel plugin (this is optional) -->
<script type="text/javascript" src="lib/jquery.mousewheel-3.0.6.pack.js"></script>

<!-- Add fancyBox -->
<link rel="stylesheet" href="source/jquery.fancybox.css?v=2.1.5" type="text/css" media="screen" />
<script type="text/javascript" src="source/jquery.fancybox.pack.js?v=2.1.5"></script>

<!-- Optionally add helpers - button, thumbnail and/or media -->
<link rel="stylesheet" href="source/helpers/jquery.fancybox-buttons.css?v=1.0.5" type="text/css" media="screen" />
<script type="text/javascript" src="source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>
<script type="text/javascript" src="source/helpers/jquery.fancybox-media.js?v=1.0.6"></script>

<link rel="stylesheet" href="source/helpers/jquery.fancybox-thumbs.css?v=1.0.7" type="text/css" media="screen" />
<script type="text/javascript" src="source/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>
<script>
$(".fancybox").fancybox({
    openEffect  : 'none',
    closeEffect : 'none',
    iframe : {
        preload: false
    }
});
</script>
		
	<!-- End Here -->
	
	<script src="js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>

	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
		//window.onbeforeunload = function() { return "You work will be lost."; };
	</script>

	<script type="text/javascript" charset="utf-8">
		$(document).ready(function(){
			$("area[rel^='prettyPhoto']").prettyPhoto();
			
			$(".gallery:first a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal',theme:'light_square',slideshow:3000, autoplay_slideshow: true});
			$(".gallery:gt(0) a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'fast',slideshow:10000, hideflash: true});

			$("#custom_content a[rel^='prettyPhoto']:first").prettyPhoto({
				custom_markup: '<div id="map_canvas" style="width:260px; height:265px"></div>',
				changepicturecallback: function(){ initialize(); }
			});

			$("#custom_content a[rel^='prettyPhoto']:last").prettyPhoto({
				custom_markup: '<div id="bsap_1259344" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6"></div><div id="bsap_1237859" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6" style="height:260px"></div><div id="bsap_1251710" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6"></div>',
				changepicturecallback: function(){ _bsap.exec(); }
			});
			
			document.getElementById('img').style.display = 'none';
			document.getElementById('del').style.display = 'none';
		});		
	</script>
	
	<script language="JavaScript" type="text/javascript">
		$(document).ready(function()
		{
			$("a.delete").click(function(e)
			{
				if(!confirm('Confirm Delete File?'))
				{
					e.preventDefault();
					return false;
				}
				return true;
			});
			$("a.update").click(function(e)
			{
				if(!confirm('Confirm Update File?'))
				{
					e.preventDefault();
					return false;
				}
				return true;
			});		
		});
		
	</script>
	
	<style>
		#content
		{
			clear: both;
			margin-top: 0.3em;
			margin-left: 0.1em;
			width: 150px;
			border: thin solid #cccccc;
			padding-top: 0.3em;
			padding-right: 0.1em;
			padding-bottom: 0.2em;
			padding-left: 0.1em;
		}	
		.container
		{
			display: inline;
			border-collapse: collapse;
		}
		.table-row
		{
			display:table-row;
			text-align: center;
		}
		.col
		{
			display:table-cell;
			padding-left: 4px;
		}	
		input[type=checkbox]
		{
			transform: scale(1.3);
			-webkit-transform: scale(1.3);
		}	
		label
		{
			font-family:Verdana;
			color: #258;
			font-weight: normal;
			font-size: 14px;
			display: inline;
			text-align: left;
		}
		img
		{
			border : 0;
		}
	</style>
</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="">
	<?php		
		$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
		$limit = 20;
		$startpoint = ($page * $limit) - $limit;
		$search = '';
		$category = 'All';
		$statement = '';
		$param = "?keyword=".$search."&category=".$category."&";

		function pagination($query, $per_page, $page = 1, $url = '?')
		{
			$query = "SELECT COUNT(*) as num FROM {$query}";
			$row = mysql_fetch_array(mysql_query($query));
			$total = $row['num'];
			$adjacents = "4";
			
			$page = ($page == 0 ? 1 : $page);
			$start = ($page - 1) * $per_page;
			
			$prev = $page - 1;
			$next = $page + 1;
			$lastpage = ceil($total / $per_page);
			$lpm1 = $lastpage - 1;
			
			$pagination = "";
			if ($lastpage > 1)
			{
				$pagination .= "<ul class='pagination'>";
				$pagination .= "<li class='details'>Page $page of $lastpage</li>";
				if ($lastpage < 5 + ($adjacents * 2))
				{
					for ($counter = 1; $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<li><a class='current'>$counter</a></li>";
						else
							$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
					}
				}
				elseif ($lastpage > 5 + ($adjacents * 2))
				{
					if ($page < 1 + ($adjacents * 2))
					{
						for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
						{
							if ($counter == $page)
								$pagination.= "<li><a class='current'>$counter</a></li>";
							else
								$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
						}
						$pagination.= "<li class='dot'>...</li>";
						$pagination.= "<li><a href='{$url}page=$lpm1'>$lpm1</a></li>";
						$pagination.= "<li><a href='{$url}page=$lastpage'>$lastpage</a></li>";
					}
					elseif ($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
					{
						$pagination.= "<li><a href='{$url}page=1'>1</a></li>";
						$pagination.= "<li><a href='{$url}page=2'>2</a></li>";
						$pagination.= "<li class='dot'>...</li>";
						for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
						{
							if ($counter == $page)
								$pagination.= "<li><a class='current'>$counter</a></li>";
							else
								$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
						}
						$pagination.= "<li class='dot'>..</li>";
						$pagination.= "<li><a href='{$url}page=$lpm1'>$lpm1</a></li>";
						$pagination.= "<li><a href='{$url}page=$lastpage'>$lastpage</a></li>";
					}
					else
					{
						$pagination.= "<li><a href='{$url}page=1'>1</a></li>";
						$pagination.= "<li><a href='{$url}page=2'>2</a></li>";
						$pagination.= "<li class='dot'>..</li>";
						for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
						{
							if ($counter == $page)
								$pagination.= "<li><a class='current'>$counter</a></li>";
							else
								$pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
						}
					}
				}
				
				if ($page < $counter - 1)
				{
					$pagination.= "<li><a href='{$url}page=$next'>Next</a></li>";
					$pagination.= "<li><a href='{$url}page=$lastpage'>Last</a></li>";
				}
				else
				{
					$pagination.= "<li><a class='current'>Next</a></li>";
					$pagination.= "<li><a class='current'>Last</a></li>";
				}
				$pagination.= "</ul>\n";
			}
			return $pagination;
		}
	?>
	
	<table width="100%" height="100%" border="0" cellpadding="0">
	<tr>
		<td width="18%" style="padding-left:10px;" valign="top" class="key-card">
		<form action="search.php" method="post">		
			<div style="color:#258; font-weight:bold; font-size:16px;">Category</div>
			<div>
				<input id="option" type="checkbox" name="field[]" value="Business"><label for="1" class="highlight">  Business</label><br/>
				<input id="option" type="checkbox" name="field[]" value="Business Reports"><label for="1" class="highlight">  Business Reports</label><br/>
				<input id="option" type="checkbox" name="field[]" value="Business Meetings"><label for="1" class="highlight">  Business Meetings</label><br/>
				<input id="option" type="checkbox" name="field[]" value="Buildings Houses Office"><label for="1" class="highlight"> Buildings</label><br/>
				<input id="option" type="checkbox" name="field[]" value="Animals"><label for="1" class="highlight">  Animals</label><br/>
				<input id="option" type="checkbox" name="field[]" value="Nature"><label for="1" class="highlight">  Nature</label><br/>
				<input id="option" type="checkbox" name="field[]" value="Icons Symbols"><label for="1" class="highlight">  Icons and Symbols</label><br/>
				
				<input id="option" type="checkbox" name="field[]" value="Building Icons"><label for="1" class="highlight">  Building Icons</label><br/>
				
				<input id="option" type="checkbox" name="field[]" value="Social media_Icons"><label for="1" class="highlight">  Social media Icons</label><br/>
				
				<input id="option" type="checkbox" name="field[]" value="Professionals"><label for="1" class="highlight">  Professionals</label><br/>
				<input id="option" type="checkbox" name="field[]" value="Technology"><label for="1" class="highlight">  Technology</label><br/>
				<input id="option" type="checkbox" name="field[]" value="Family People"><label for="1" class="highlight">  Family / People</label><br/>
				<input id="option" type="checkbox" name="field[]" value="Money"><label for="1" class="highlight">  Money</label><br/>
				<input id="option" type="checkbox" name="field[]" value="Maps Globe"><label for="1" class="highlight">  Maps and Globe</label><br/>
				<input id="option" type="checkbox" name="field[]" value="Graphs"><label for="1" class="highlight">  Graphs</label><br/>
				<input id="option" type="checkbox" name="field[]" value="Calendar"><label for="1" class="highlight">  Calendar</label><br/>
				<input id="option" type="checkbox" name="field[]" value="Logistics"><label for="1" class="highlight">  Logistics</label><br/>
				<input id="option" type="checkbox" name="field[]" value="Teams"><label for="1" class="highlight">  Teams</label><br/>
				<input id="option" type="checkbox" name="field[]" value="Games"><label for="1" class="highlight">  Games</label><br/><br/>
			</div><br/>
			
			<input id="option1" type="radio"  name="field1" value="Images"><label for="1" class="highlight">  Images</label><br/>			
			<input id="option1" type="radio"  name="field1" value="Vectors"><label for="1" class="highlight">  Vectors</label><br/>
			<input id="option1" type="radio"  name="field1" value="Illustrations"><label for="1" class="highlight">  Illustrations</label><br/><br/>
						
			<div width='100%' align='center'><input type="submit" name="submit" value="Search" style="height:25px;" /></div><br/>

			<?php
				$sub = "images where";
				$keys = '';		
				
				if(isset($_POST['submit']))
				{
				                if(isset ($_REQUEST['field1']))
                                       $field1 = $_REQUEST['field1'];
									  
                                   else
                                        $field1 ='';
					
					if(isset ($_POST['field1'])){
						
						$category = $_POST['field1'];
					}					
										
                     if(!empty($_POST['field']) or  !empty($_POST['field1']))
					{
                      	foreach($_POST['field'] as $selected)
						{
							$keys .= $selected . " ";
						}
											
						$keys = trim($keys);
						$items = explode(" ", $keys);
						
						/*added code shashi 07-10-2016*/
						
						//echo $_POST['field1'];						
						//$category = $_POST['field1'];
						
						for ($i = 0; $i < count($items); $i++)
						{
							$item = $items[$i];		
							if($i==0)
								$sub .= " tag LIKE '%$item%' and category LIKE '%$field1%'";
							else
								$sub .= " or tag LIKE '%$item%' and category LIKE '%$field1%'";
							
						}						
						$param = "?keyword=".$keys."&category=".$category."&";    	
					}
					else
					{
						echo "<div style='font-size:14px; color:#789;' align='center' width='100%'>Please Select keywords...</div>";
					}	
				}
			?>
		</form>
		</td>
		
		<td width="82%" valign="top" class="search-card">
			<h1>Search</h1>
			<div align="center">
			<form action="" method="Get">
				<table height="30px" border="0" style="background-color:#EDF5FE; color:teal; margin:auto;">
				<tr>
					<td align="right" width="50%">
						<input name="keyword" type="text" id="Keyword" placeholder='Search images' onclick="this.value = '';" value="<?php if (isset($_REQUEST["keyword"])){echo $_REQUEST["keyword"];} ?>" style="height: 30px;"/>
					</td>
					
					<td width="30%">
						<select name="category" style="height:30px; width:150px">
							<option value="All" selected>All Categories</option>
							<option value="Images">Images</option>
							<option value="Vectors">Vectors</option>
							<option value="Illustrations">Illustrations</option>
							<option value="Storyline">Storyline</option>
							<option value="Captivate">Captivate</option>
							<option value="Videos">Videos</option>
							<option value="Audio">Audio</option>
							<option value="Flash">Flash</option>
							<option value="AfterEffects">AfterEffects</option>
							<option value="2DIllustrations">2DIllustrations</option>
						</select>
					</td>
					<td width="20%">
						<input type="submit" name="browse" value="Search" style="height: 30px;" />
					</td>
				</tr>
				</table>
			</form>
			</div>
			<div class="gallery clearfix"></div>
			<div class="container">
			<?php
				if (isset($_REQUEST["id"]))
				{
					$statement = "images where name='" . $_REQUEST["id"] . "'";
				}
				else
				{
					$statement = "images";
					
				}
				if(isset($_REQUEST["keyword"]))
				{
					$search=trim($_REQUEST["keyword"]);
					$category = $_REQUEST['category'];
					$words=split(" ",$search);
					$q = "";
					$i = 0;
					while(list($key,$val)=each($words))
					{
						if($val <> " " and strlen($val) > 0)
						{
							if($i==0)
								$q .= " tag LIKE '%$val%'";
							else
								$q .= " or tag LIKE '%$val%'";
							$i++;
						}
					}
					
									
					if(!empty($search))
					{
						if($category == "All")
						{
							$statement = " images where $q ";
						}
						else
						{
							$statement = " images where ($q) and category='$category' ";
						}
					}
					else
					{
						if($category == "All")
						{
							
							$statement = " images ";
						}
						else
						{
							$statement = " images where category='$category' ";
						}
					}
					$param = "?keyword=".$search."&category=".$category."&";
				}
				
				if(!empty($_POST['field']))
				{
					$statement = $sub;				
				}

				$query = mysql_query("SELECT * FROM {$statement} order by name asc LIMIT {$startpoint} , {$limit}");
				$num_rows = mysql_num_rows($query);
 
				$r = 5;
				$j = 0;
				
				$images = ["jpg","jpeg","png","gif"];

				while ($data = mysql_fetch_assoc($query))
				{
					$filename = $data['name'];
					$myFileType = split ("\.", $filename);
					$title = "Name : ".$data['name']."<br/>Size : ".$data['size']."<br/>Dimensions : ".$data['width']."x".$data['height'];
					$extension = explode(".",$filename)[1];
					if(!in_array($extension, $images))
						$filename = explode(".",$filename)[0].".jpg";
					if($j == 0)
						echo "<div class='table-row'>";
			?>
			<div class="col">
				<div class="gallery" id="content">
					<div align="center">
					
						<a class="fancybox" data-fancybox-type="iframe" rel="<?php if($myFileType[1] == "cptx") echo ""; else if($myFileType[1] == "story")	echo ""; else if($myFileType[1] == "mp4") echo ""; else if($myFileType[1] == "flv") echo ""; else if($myFileType[1] == "mkv") echo ""; else if($myFileType[1] == "mp3") echo ""; else if($myFileType[1] == "wav") echo ""; else if($myFileType[1] == "fla") echo ""; else echo "prettyPhoto";?>" href="<?php if($myFileType[1] == "cptx") echo "uploads/" . $myFileType[1] . "/" . $myFileType[0] . "/index.html"; 
						else if($myFileType[1] == "story") echo "uploads/" . $myFileType[1] . "/" . $myFileType[0] . "/story.html"; 
						else if($myFileType[1] == "mp4") echo "uploads/" . $myFileType[1] . "/" . $myFileType[0] . ".mp4";
						else if($myFileType[1] == "flv") echo "uploads/" . $myFileType[1] . "/" . $myFileType[0] . ".flv";
						else if($myFileType[1] == "mkv") echo "uploads/" . $myFileType[1] . "/" . $myFileType[0] . ".mkv";
						else if($myFileType[1] == "mp3") echo "uploads/" . $myFileType[1] . "/" . $myFileType[0] . ".mp3";
						else if($myFileType[1] == "wav") echo "uploads/" . $myFileType[1] . "/" . $myFileType[0] . ".wav";
						else if($myFileType[1] == "fla") echo "uploads/" . $myFileType[1] . "/" . $myFileType[0] . ".swf";
						else echo "thumbs/" . $filename;?>" title="<?php echo $data['name'];?>" name="<?php echo $title;?>">
						<img src="<?php if($myFileType[1] == "mp3") echo 'images/icons/mp3.png'; else if($myFileType[1] == "wav") echo 'images/icons/wav.png'; else if($myFileType[1] == "mp4") echo 'images/icons/mp4.png'; else if($myFileType[1] == "mkv") echo 'images/icons/mkv.png'; else if($myFileType[1] == "flv") echo 'images/icons/flv.png'; else if($myFileType[1] == "zip") echo 'images/icons/zip.png'; else echo 'thumbs/' . $filename;?>" width="140px" height="120px" /></a>
					</div>
					<div align="center" style="padding-top:10px; display:<?php echo $view_stat; ?>;">

						<a href="edit.php?id=<?php echo $data['id'];?>&mode=" class="links" title="Edit"><img src="images/ed.png" width="25" height="25" style="display:<?php echo $ed_stat; ?>" ></a>
						
						<a href="downloadFile.php?filename=<?php echo $data['name'];?>&username=<?php echo $_SESSION['user'];?>" class="links" title="Download"><img src="images/dd.png" width="25" height="25" style="display:<?php echo $dd_stat;?>" ></a>
						
						<a href="deleteFile.php?filename=<?php echo $data['name'];?>" class="links" title="Delete" onclick="return confirm('Confirm Delete File?');"><img src="images/dt.png" width="25" height="25" style="display:<?php echo $dt_stat; ?>" ></a>
					</div>
				</div>
			</div>		

			<?php			
				$j++;
				if($j == $r)
				{
					echo "</div>";
					$j = 0;
				}
			}
			?>
		</div>

		<div style="color:#258; text-align:center;">
			<?php
				if ($num_rows > '0')
				{
					echo '<b> Showing ';
					echo $num_rows;
					echo '</b>&nbsp;Records ';
				}
				else
				{
					echo '<b>No Records Found</b>';
				}
			?>
		</div>
		<br/>
		<div class="pagination">
			<?php
				echo pagination($statement, $limit, $page, $param); ?>
		</div>
		<div class="login-help" style="display:<?php echo $view_stat; ?>">
			<a href="main.php">Back to Main</a>
		</div>
		</td>
	</tr>
	</table>

</body>
</html>