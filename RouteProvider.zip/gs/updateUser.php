<?php
require_once "connect.php";

if(isset($_GET["m"]))
{
	$mail = $_GET['m'];
	$type = $_GET['t'];
	$status = $_GET['s'];
		
		
	$sql = "UPDATE users SET type='".$type."', status='".$status."' WHERE mail='".$mail."'";
	
	$result = mysql_query($sql) or die(mysql_error());
	//*****************************************
	require_once "Mail.php"; // PEAR Mail package 
	require_once ('Mail/mime.php'); // PEAR Mail_Mime packge
	
	$from   = 'webadmin@chrp-india.com';
	$to     = $mail;
	$replyto  = $mail;
	$subject  =" CHRP-INDIA Library Access ";
	$headers  = array ('From' => $from,'To' => $to, 'Subject' => $subject, 'Reply-To' => $replyto);
	$html = '<html>
					<head>
						<title>CHRP-INDIA</title>
					</head>
				</html>';

	$crlf = "\n"; 
	$mime = new Mail_mime($crlf);
	$mime->setHTMLBody($html);  //when  HTML is used in body
	$body      = $mime->get(); 
	$headers   = $mime->headers($headers);

	//$host      = "smtp.gmail.com";
	$port      = "25";//For only google aps SMTP port try these (465 or 587).
	
	//$username  = "webadmin@chrp-india.com"; //Email Id	
	//$password  = "web2015$$$"; //Password
	
	$username  = "sending@labelhosting.com"; //Email Id	
	$password  = "fafrUb7e"; //Password
	
	//echo "<script type='text/javascript'>alert('$to');</script>";
	$smtp      = Mail::factory('smtp', array ('port' => $port, 'auth' => true, 'username' => $username,'password' => $password)); 
	
	//**********************************************
	
	if($status == "Pending")
	{
		$sql = "SELECT * FROM users WHERE mail='".$mail."'";
		$result = mysql_query($sql) or die(mysql_error());
		$data = mysql_fetch_array($result);
		mysql_close();
		
		$subject = "CHRP-INDIA Library Access";
		$body = "<div style='font-family:verdana; font-size:14px;'>Dear " . $data['username'] . ", <br/><br/>Your account is inactive.<br/><br/>Please contact <a href='hhttp://www.chrp-india.com/library/index.php'>admin</a> for more details...";
		
		$mail = $smtp->send($to, $headers, $body);
					
				if (PEAR::isError($mail))
				{
					echo("<p>" . $mail->getMessage() . "</p>");
					$gmsg = "error";
				} 
				else
				{
					$gmsg = "correct";
					$gmsg = '<p class="send-true" style="color: #0183c0; margin-bottom:15px; border:1px solid #cccccc; padding: 10px;"><strong>Dear '. $name .',</strong></br></br>Thanks for applying at CHRP-INDIA.</p>';
				}
	}
	else if($status == "Block")
	{
		$sql = "SELECT * FROM users WHERE mail='".$mail."'";
		$result = mysql_query($sql) or die(mysql_error());
		$data = mysql_fetch_array($result);
		mysql_close();
		
		$subject = "CHRP-INDIA Library Access";
		$body = "<div style='font-family:verdana; font-size:14px;'>Dear " . $data['username'] . ", <br/><br/>Your account is blocked.<br/><br/>Please contact <a href='hhttp://www.chrp-india.com/library/index.php'>admin</a> for more details...";
		
		$mail = $smtp->send($to, $headers, $body);
							
				if (PEAR::isError($mail))
				{
					echo("<p>" . $mail->getMessage() . "</p>");
					$gmsg = "error";
				} 
				else
				{
					$gmsg = "correct";
					$gmsg = '<p class="send-true" style="color: #0183c0; margin-bottom:15px; border:1px solid #cccccc; padding: 10px;"><strong>Dear '. $name .',</strong></br></br>Thanks for applying at CHRP-INDIA.</p>';
				}
	}
	else if($status == "Approve")
	{		
		$sql = "SELECT * FROM users WHERE mail='".$mail."'";
		$result = mysql_query($sql) or die(mysql_error());
		$data = mysql_fetch_array($result);
		mysql_close();
			
				$subject = "CHRP-INDIA Library Access";
				$body = "<div style='font-family:verdana; font-size:14px;'>Dear " . $data['username'] . ", <br/><br/>Welcome to CHRP-Library<br/><br/>Your account is activated.<br/><br/>Your login details are<br/><br/>UserName : ".$data['username']."<br/>Password : ".$data['password']."<br/>Security Text : ".$data['security_txt']."<br/>Account Type : ".$data['type']."<br/><br/>Click here to <a href='hhttp://www.chrp-india.com/library/index.php'>login</a> to CHRP Media Library</div>";
						
				$mail = $smtp->send($to, $headers, $body);
			
				
				if (PEAR::isError($mail))
				{
					echo("<p>" . $mail->getMessage() . "</p>");
					$gmsg = "error";
				} 
				else
				{
					$gmsg = "correct";
					$gmsg = '<p class="send-true" style="color: #0183c0; margin-bottom:15px; border:1px solid #cccccc; padding: 10px;"><strong>Dear '. $name .',</strong></br></br>Thanks for applying at CHRP-INDIA.</p>';
				}			
	}
	header("Location:userAccounts.php?mode=success");
}
else
{
	header("Location:userAccounts.php?mode=pleaseFill");	
}
?>

