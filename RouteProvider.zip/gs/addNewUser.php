<?php
require_once "connect.php";

//include_once "sendMail.php";

if(isset($_POST["Submit"]))
{
	$empid = trim($_POST['empid']);
	$user = trim($_POST['username']);
	$pwd = trim($_POST['password']);
	$type = "User";
	$email = trim($_POST['mail']);
	$security = trim($_POST['security']);
	$status = "Pending";
	
	$emailErr = "";
	if($empid != "" && $user != "" && $pwd != "" && $email != "" && $security != "")
	{
		if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$email))
		{
			$emailErr = "Invalid email format";
		}
		
		if($emailErr == "")
		{
			$qry = "SELECT * FROM users WHERE mail='".$email."' OR username='".$user."'";
			$result = mysql_query($qry) or die(mysql_error());
			$num_rows = mysql_num_rows($result);
			
			if($num_rows == 0)
			{
				$sql = "INSERT INTO users (emp_id, username, password, type, mail, security_txt, status) VALUES ('".$empid."', '".$user."', '".$pwd."', '".$type."', '".$email."', '".$security."', '".$status."')";
				$result1 = mysql_query($sql) or die(mysql_error());
				mysql_close();
				
				//*****************************************
				require_once "Mail.php"; // PEAR Mail package 
				require_once ('Mail/mime.php'); // PEAR Mail_Mime packge
						
				$from   = $email;
				echo "<script type='text/javascript'>alert('$email');</script>";
				$to     = 'praveen.b@chrp-india.com';
				$replyto  = $email;
				$subject  = $user . " CHRP-INDIA";
				$headers  = array ('From' => $from,'To' => $to, 'Subject' => $subject, 'Reply-To' => $replyto);	
				$headers1  = array ('From' => $to,'To' => $from, 'Subject' => 'Acknowledgement for your request to CHRP-INDIA', 'Reply-To' => $to);
				
				$html     = 'Hi,<br/><br/>
				<strong>'. $_POST['username'] . '</strong> has been registered with CHRP-INDIA library for the access.<br/><br/>';
				
				$html1     = 'Dear ' . $_POST['username'] . ',
	
We would like to acknowledge that we have received your request for CHRP-INDIA library access.

A support representative will be reviewing your request and send you an update soon.

Thank you for registering with CHRP-INDIA library.
						
Sincerely,
CHRP-INDIA Pvt. Ltd.
Support Team'; 	

								
				$crlf = "\n"; 
				$mime = new Mail_mime($crlf);
				$mime->setHTMLBody($html);  //when  HTML is used in body
				//$mime->addAttachment("Carrer_resume/" . $random_digit, $fileName);
				$body      = $mime->get(); 
				$headers   = $mime->headers($headers);
				
				#$host      = "smtp.gmail.com";
				$port      = "25";//For only google aps SMTP port try these (465 or 587).
				$username  = "sending@labelhosting.com"; //Email Id
				$password  = "fafrUb7e"; //Password
				$smtp      = Mail::factory('smtp', array ('port' => $port, 'auth' => true, 
				'username' => $username,'password' => $password));
								
				$mail = $smtp->send($to, $headers, $body); 
					if (PEAR::isError($mail))
					{
						echo("<p>" . $mail->getMessage() . "</p>");
						$gmsg = "error";
					} 
					else
					{
						$gmsg = '<p class="send-true" style="color: #0183c0; margin-bottom:15px; border:1px solid #cccccc; padding: 10px;"><strong>Dear '. $name .',</strong></br></br>Thanks for applying at CHRP-INDIA.</p>';
						$mail = $smtp->send($replyto, $headers1, $html1);
					}			
				//**********************************************
				header("Location:register.php?mode=success");
			}
			else
			{
				header("Location:register.php?mode=exist");		
			}
		}
		else
		{
			header("Location:register.php?mode=email");
		}
	}
	else
	{
		header("Location:register.php?mode=pleaseFill");	
	}
}
?>