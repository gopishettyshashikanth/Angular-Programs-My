<?php
require_once "connect.php";

$sql = "SELECT name,size FROM images WHERE 1";
$query = mysql_query($sql) or die(mysql_error());
$login_counter = mysql_num_rows($query);
echo "Total Files : ".$login_counter."</br>";
if ($login_counter > 0)
{
	while ($data = mysql_fetch_assoc($query))
	{
		$f = "uploads\\".$data['name'];
		?>
		<a href="down.php?file=<? echo $f; ?>" class="links" title="Download"><img src="images/dd.png" width="15" height="15"></a>
		<a href="downloadFile.php?filename=<?php echo $data['name'];?>&username=<?php echo $_SESSION['user'];?>" class="links" title="Download"><img src="images/dd.png" width="15" height="15" style="display:<?php echo $dd_stat; ?>" ></a>
		<a href="deleteFile.php?filename=<?php echo $data['name'];?>" class="links" title="Delete" onclick="return confirm('Confirm Delete File?');"><img src="images/dt.png" width="15" height="15" style="display:<?php echo $dt_stat; ?>" ></a>

		<?
		echo $data['name']." *** ".$data['size']."</br>";
	}
}

$sql = "SELECT * FROM users WHERE 1";
$query = mysql_query($sql) or die(mysql_error());
$login_counter = mysql_num_rows($query);
mysql_close();
if ($login_counter > 0)
{
	while ($data = mysql_fetch_assoc($query))
	{
		echo $data['username']." ^^^ ".$data['password']." ^^^ ".$data['type']." ^^^ ".$data['mail']." ^^^ ".$data['status']."</br>";
	}
}	
?>