<!DOCTYPE html>
<?php
	error_reporting(0);
	include "banner.php";
	session_start();
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>CHRP Library</title>
	<!--title>We believe in the nature and future of learning and knowledge transfer.</title-->
	<meta class="viewport" name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="Keywords" content="A bespoke online learning solutions company"/>
	<meta name="Description" content="A bespoke online learning solutions company...">
	<meta name="author" content="chrp-india.com"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta charset="utf-8">
	
	<link rel="alternate" hreflang="x-default" href="http://www.chrp-india.com/" />

  <link rel="stylesheet" href="library/css/buttons/social-icons.css">
  <link rel="stylesheet" href="library/css/font-awesome.min.css">
  <link rel="stylesheet" href="library/css/bootstrap.min.css">
  <link rel="stylesheet" href="library/css/jslider.css">
  <link rel="stylesheet" href="library/css/settings.css">
  <link rel="stylesheet" href="library/css/jquery.fancybox.css">
  <link rel="stylesheet" href="library/css/animate.css">
  <link rel="stylesheet" href="library/css/video-js.min.css">
  <link rel="stylesheet" href="library/css/morris.css">
  <link rel="stylesheet" href="library/css/royalslider/royalslider.css">
  <link rel="stylesheet" href="library/css/royalslider/skins/minimal-white/rs-minimal-white.css">
  <link rel="stylesheet" href="library/css/layerslider/layerslider.css">
  <link rel="stylesheet" href="library/css/ladda.min.css">
  <link rel="stylesheet" href="library/css/style.css">
  <link rel="stylesheet" href="library/css/responsive.css">
  <link rel="stylesheet" href="library/css/customizer/pages.css">
  <link rel="stylesheet" href="library/css/customizer/home-pages-customizer.css">

	<link rel="stylesheet" href="library/css/mystyle.css">
	  
	<!-- IE Styles-->
	<link rel='stylesheet' href="library/css/ie/ie.css">
	<link rel="shortcut icon" href="library/img/favicon.ico">

<!-- End 

<head> -->
	
	<link rel='stylesheet' href='css/jquery-ui.css' />
	<link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
		//window.onbeforeunload = function() { return "You work will be lost."; };
	</script>

<!-- Start Alexa Certify Javascript -->
<script type="text/javascript">
_atrk_opts = { atrk_acct:"koxHk1ao6C524B", domain:"chrp-india.com",dynamic: true};
(function() { var as = document.createElement('script'); as.type = 'text/javascript'; as.async = true; as.src = "https://d31qbv1cthcecs.cloudfront.net/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();
</script>
<noscript><img src="https://d5nxst8fruw4z.cloudfront.net/atrk.gif?account=koxHk1ao6C524B" style="display:none" height="1" width="1" alt="" /></noscript>
<!-- End Alexa Certify Javascript -->  



</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="" class="boxed">
	<br/>
	<section id="main">
	<div class="login-card boxed">
		<h1>Login</h1>
		<form action="controlPanel.php" method="post">
			<input type="text" name="username" placeholder="Username" />
			<input type="password" name="password" placeholder="Password" />
			<div class="login-help" style="text-align:right"><a href="forgot.php">Forgot password?</a></div>
			<br/>
			<input type="submit" name="login" class="login login-submit" value="Login" />
		</form>
		<div class="login-help">
		<?php
		
		if(isset($_GET['mode']))
		{
		session_destroy();
			if($_GET['mode']=='invalid')
			{
				echo "<span style=color:red;>Invalid Username/Password...</span>";
			}
			if($_GET['mode']=='fill')
			{
				echo "<span style=color:red;>Enter Username/Password...</span>";
			}
			if($_GET['mode']=='inactive')
			{
				echo "<span style=color:red;>Your account is not activated<br/>wait for admin responce...</span>";
			}
			if($_GET['mode']=='block')
			{
				echo "<span style=color:red;>Your account is blocked<br/>contact admin for help...</span>";
			}
		}
		?>
		</div>
		<br/>
		<div class="login-help">
			<a href="register.php">Register</a>
		</div>
	</div>
	</section>
	
	<table width="100%" height="10px" style="position:fixed; left:0px; right:0px; bottom:0px;" border="0" cellpadding="5">
	<tr>
		<td align="center" style="color:#008ed2; font-size:12px;">
			Copyright &copy; CHRP-INDIA Pvt. Ltd., 2014
		</td>
	</tr>
	</table>
</body>
</html>