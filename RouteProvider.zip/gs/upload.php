<!DOCTYPE html>
<?php
	error_reporting(0);
	include("session.php");
	$config = parse_ini_file("config.ini");
	$config['url'] = basename($_SERVER['SCRIPT_NAME']);
	$f = fopen("config.ini","w");
	foreach($config as $name => $value)
	{
		fwrite($f, "$name = \"$value\"\n");
	}
	fclose($f);
?>
<html>
<head>
	<meta charset="UTF-8" />
	<title>CHRP Library</title>
	<link rel='stylesheet' href='css/jquery-ui.css' />
    <link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
	<script src="js/jquery-1.11.1.min.js"></script>
	
	<script type="text/javascript">
        function hide()
		{
			document.getElementById('fileJPG').style.display = 'none';
			document.getElementById('fileZIP').style.display = 'none';
			document.getElementById('filesNew').value = '';
			document.getElementById('zipFileNew').value = '';
			document.getElementById('cate').style.display = 'none';
			document.getElementById('tag').style.display = 'none';
			document.getElementById('cate').value = "";
			document.getElementById('tag').value = "";			
			document.getElementById("Submit").style.cursor = 'default';
			document.getElementById("Submit").disabled = true;
		}
        function show()
		{
          document.getElementById('cate').style.display = 'inline';
          document.getElementById('tag').style.display = 'inline';
        }
		function changeText()
		{	
			document.getElementById("cate").style.color = 'inherit';
			enableSubmit();
		}
		
		function enableSubmit()
		{
			document.getElementById("Submit").disabled = false;
			document.getElementById("Submit").style.cursor = 'pointer';

			if(document.getElementById('fileJPG').style.display == 'inline')
			{
				if(document.getElementById('cate').value == "" || document.getElementById('tag').value == "" || document.getElementById('filesNew').value == "")
				{
					document.getElementById("Submit").disabled = true;
					document.getElementById("Submit").style.cursor = 'default';
				}
			}
			else
			{
				if(document.getElementById('cate').value == "" || document.getElementById('tag').value == "")
				{
					document.getElementById("Submit").disabled = true;
					document.getElementById("Submit").style.cursor = 'default';
				}				
			}			
		}
	</script>
	<script>
		$(document).ready(function()
		{
			$('textarea#tag').keyup(function()
			{
				enableSubmit();
			});
			$( "#Submit" ).click(function(event)
			{
				if($('#myForm').valid())
				{
					$(event.target).attr("disabled", "disabled");
				}
			});
		});
	</script>

	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
		//window.onbeforeunload = function() { return "You work will be lost."; };
	</script>
</head>
<body onload="noBack(); hide();" onpageshow="if (event.persisted) noBack();" onunload="">
	
	<div class="login-card">
		<h1>Upload</h1>
		<form id="myForm" action="uploadFile.php" method="post" enctype="multipart/form-data">
			<input type="file" id="files" name="files" class="fileData" />
			<br/><br/>
			<div id="fileJPG">
				<input type="file" id="filesNew" name="filesNew" class="fileData" value="" accept="image/jpeg" />
				<br/><br/>
			</div>
			<div id="fileZIP">
				<input type="file" id="zipFileNew" name="zipFile" class="fileData" value="" accept="application/zip" />
				<br/><br/>
			</div>
			<div id="selectedFiles" align="center" class="selectedImage"></div><br/>
			<select class="form-control" name="category" id="cate" style="color:#aaa;" onchange="changeText();">
				<option value="" selected disabled>Select Category</option>
				<option value="Images" style="color:#000;">Images</option>
				<option value="Vectors" style="color:#000;">Vectors</option>
				<option value="Illustrations" style="color:#000;">Illustrations</option>	
				<option value="Storyline" style="color:#000;">Storyline</option>
				<option value="Captivate" style="color:#000;">Captivate</option>
				<option value="Videos" style="color:#000;">Videos</option>
				<option value="Audio" style="color:#000;">Audio</option>
				<option value="Flash" style="color:#000;">Flash</option>
				<option value="AfterEffects" style="color:#000;">AfterEffects</option>
				<option value="2DIllustrations" style="color:#000;">2DIllustrations</option>
			</select>
			<textarea class="form-control" name="tag" id="tag" style="max-width:90%; min-height:70px;"  placeholder="Enter key words for searching this image" maxlength="255"></textarea>
			<input type="submit" id="Submit" name="Submit" value="Submit" class="login login-search" onclick="this.value='Sending, please wait...';"/>
		</form>
		<div class="login-help">
			<a href="main.php">Back to Main</a>
		</div>
		<br/>
		<script>
			var images = ["jpg","jpeg","png","gif"];
			var fileType = ["jpg","jpeg","png","gif","eps","ai","tif","tiff","psd","pdf","svg","cdr","tga","zip","cptx","mp3","story","mp4","fla","flv","mkv","wav"];
			var selDiv = "";
			document.addEventListener("DOMContentLoaded", init, false);
			var img = document.createElement("img");
			var ext1,ext2;
			var fname1,fname2;
			
			function init()
			{
				document.querySelector('#files').addEventListener('change', handleFileSelect, false);
				selDiv = document.querySelector("#selectedFiles");
				
				document.querySelector('#filesNew').addEventListener('change', handleFileSelectNew, false);
				document.querySelector('#zipFileNew').addEventListener('change', handleFileSelectNew1, false);
				
			}
			function handleFileSelect(e)
			{
				hide();
				if(!e.target.files || !window.FileReader) return;
				selDiv.innerHTML = "";
				var files = e.target.files;
				var filesArr = Array.prototype.slice.call(files);

				filesArr.forEach(function(f)
				{
					fname1 = f.name.split('.')[0];
					ext1 = (f.name.split('.').pop()).toLowerCase();
					var reader = new FileReader();
					reader.onload = function (e)
					{
						if(fileType.indexOf(ext1) == -1)
						{
							selDiv.innerHTML = "<b><font face='verdana' color='red' size=2>Unknown File Format!!!</font></b>";
							return;
						}
						if(Math.round(f.size/1024) >= 102400)//51200
						{
							selDiv.innerHTML = "<b><font face='verdana' color='red' size=2>File is too large! <br/> (max size : 50MB)</font></b>";
							return;
						}
						
						if(images.indexOf(ext1) == -1)
						{
							img.src = "images/icons/" + ext1 + ".png";
							if(ext1 == "mp3" || ext1 == "wav")
							{
								document.getElementById('fileJPG').style.display = 'none';
								document.getElementById('fileZIP').style.display = 'none';
							}
							else if(ext1 == "mp4" || ext1 == "flv" || ext1 == "mkv" || ext1 == "ai" || ext1 == "tiff" || ext1 == "tif" || ext1 == "eps")
							{
								document.getElementById('fileJPG').style.display = 'inline';
								document.getElementById('fileZIP').style.display = 'none';
							}
							else if(ext1 == "cptx" || ext1 == "story" || ext1 == "fla")
							{
								document.getElementById('fileJPG').style.display = 'inline';
								document.getElementById('fileZIP').style.display = 'inline';
							}
						}
						else
						{
							img.src = e.target.result;
						}

						var html = "<img id='im' alt='Unknown Format' src=\'" + img.src + "'><br/><b>Name: </b>" + f.name + "<br/><b>Type: </b>" + f.type + "<br/><b>Size: </b>"+ Math.round(f.size/1024) + "KB<br/><b>Dimensions: </b>" + img.width + " x " + img.height;
						
						selDiv.innerHTML += html;
						show();
					}
					reader.readAsDataURL(f);
				});
			}
			function handleFileSelectNew(e)
			{
				enableSubmit();
				var filesArr = Array.prototype.slice.call(e.target.files);				
				filesArr.forEach(function(f)
				{
					fname2 = f.name.split('.')[0];
					ext2 = (f.name.split('.').pop()).toLowerCase();

					if(fname1 != fname2 || ext2 != "jpg")
					{
						alert("Please Select JPG file with the same name...!");
						document.getElementById('filesNew').value = '';
						enableSubmit();
					}
					else
					{
						var reader = new FileReader();
						reader.onload = function (e)
						{
							document.getElementById('im').src = e.target.result;
						}
						reader.readAsDataURL(f);
					}
				});
			}
			// Added on 19-03-15..............
			function handleFileSelectNew1(e)
			{
				enableSubmit();
				var filesArr = Array.prototype.slice.call(e.target.files);				
				filesArr.forEach(function(f)
				{
					fname2 = f.name.split('.')[0];
					ext2 = (f.name.split('.').pop()).toLowerCase();

					if(fname1 != fname2 || ext2 != "zip")
					{
						alert("Please Select zip file with the same name...!");
						document.getElementById('zipFileNew').value = '';
						enableSubmit();
					}
					else
					{
						var reader = new FileReader();
						reader.onload = function (e)
						{
							document.getElementById('im').src = e.target.result;
						}
						reader.readAsDataURL(f);
					}
				});
			}
			
		</script>		
		
		<div class="login-help">
		<?php
			if(isset($_GET['mode']))
			{
				if($_GET['mode']=='success')
					echo "<span style=color:green;>File is uploaded successfully!</span>";
				if($_GET['mode']=='fill')
					echo "<span style=color:red;>Please fill all fields...</span>";
				if($_GET['mode']=='exist')
					echo "<span style=color:red;>Already exist.</span>";
				if($_GET['mode']=='fail')
					echo "<span style=color:red;>Please upload file with max size 100MB only...</span>";
				switch($_GET['mode'])
				{
					case 1:
					case 2:
						echo "<span style=color:red;>The uploaded file exceeds the MAX_FILE_SIZE (100MB).</span>";
						break;
					case 3:
					case 4:
					case 5:
					case 6:
					case 7:
						echo "<span style=color:red;>No file was uploaded!</span>";
						break;
				}
			}
		?>
		</div>
	</div>
</body>
</html>