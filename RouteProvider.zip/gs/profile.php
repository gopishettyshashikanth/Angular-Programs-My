<!DOCTYPE html>
<?php
	include("session.php");
	$config = parse_ini_file("config.ini");

	if(isset($_GET['mode'])) // && $_GET['mode']=="success")
	{
		$redirect = "index.php";
		$page = "LOGOUT";
		$user = $pwd = $id = $mail = $text = "";
	}
	else
	{
		//$redirect = $config['url'];
		$redirect = ($_SESSION['type']!="Admin")?"search.php":"main.php";
		$page = "CLOSE";
		
		$user = $_SESSION["user"];
		
		$sql = "SELECT * FROM users WHERE username='$user';";
		$query = mysql_query($sql) or die(mysql_error());
		mysql_close();
		$data = mysql_fetch_array($query);
		$id = $data["emp_id"];
		$pwd = $data["password"];
		$mail = $data["mail"];
		$text = $data["security_txt"];
	}
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>CHRP Library</title>
	<link rel='stylesheet' href='css/jquery-ui.css' />
	<link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
	<script src="js/jquery-1.11.1.min.js"></script>
	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
		//window.onbeforeunload = function() { return "You work will be lost."; };

		function enableSubmit()
		{
			document.getElementById("Submit").disabled = false;
			document.getElementById("Submit").style.cursor = 'pointer';

			if(document.getElementById('id').value.trim() == "" || document.getElementById('pwd').value.trim() == "" || document.getElementById('txt').value.trim() == "")
			{
				document.getElementById("Submit").disabled = true;
				document.getElementById("Submit").style.cursor = 'default';

				if(GetURLParameter('mode') != undefined && GetURLParameter('mode') != '')
				{
					document.getElementById("id").disabled = true;
					document.getElementById("pwd").disabled = true;
					document.getElementById("txt").disabled = true;
				}
			}
		}
		
		function GetURLParameter(sParam)
		{
			var sPageURL = window.location.search.substring(1);
			var sURLVariables = sPageURL.split('&');
			for (var i = 0; i < sURLVariables.length; i++)
			{
				var sParameterName = sURLVariables[i].split('=');
				if (sParameterName[0] == sParam)
				{
					return sParameterName[1];
				}
			}
		}
	</script>
	<script>
		$(document).ready(function()
		{
			//$('input:submit').css('cursor','pointer');
			enableSubmit();
			$('#id,#txt,#pwd').keyup(function()
			{
				enableSubmit();
			});
		});
	</script>
</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="">
	
	<div class="login-card">
		<h1>Update Profile</h1>
		<form action="updateProfile.php" method="post" id="regForm">
			<input type="text" name="empid" id="id" placeholder="Employee ID" value="<?php echo $id;?>" maxlength="15" />
			<input type="text" name="username" placeholder="User Name" value="<?php echo $user;?>" disabled />
			<input type="password" name="password" id="pwd" placeholder="Password" value="<?php echo $pwd;?>" maxlength="20" />
			<input type="text" name="mail" placeholder="Email" value="<?php echo $mail;?>" disabled />
			<input type="text" name="security" id="txt" placeholder="Security Text" value="<?php echo $text;?>" maxlength="20" />
			<input type="submit" name="Submit" id="Submit" class="login login-submit" value="Update" />
		</form>
		<div class="login-help">
		<?php
			if(isset($_GET['mode']))
			{
				if($_GET['mode']=='success')
				{
					echo "<span style=color:green;>Your Profile is Updated Successfully!</span>";
				}
				if($_GET['mode']=='pleaseFill')
				{
					echo "<span style=color:red;>Please fill all details...</span>";
				}
			}
		?>
		</div>
		</br/>
		<div class="login-help">
			<a href="<?php echo $redirect; ?>" id="close"><?php echo $page; ?></a>
		</div>		
	</div>
	
	<!--table width="100%" height="10px" style="position:fixed; left:0px; right:0px; bottom:0px;" border="0" cellpadding="5">
	<tr>
		<td align="center" style="color:#008ed2; font-size:12px;">
			Copyright &copy; CHRP-INDIA Pvt. Ltd., 2014
		</td>
	</tr>
	</table-->
</body>
</html>