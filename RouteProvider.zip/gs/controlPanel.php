<?php
include_once "connect.php";
/*
we post the variables we recieve from POST method
*/
$username = $_POST['username'];
$password = $_POST['password'];

if($username != "" && $password != "")
{
	$sql = "SELECT * FROM users WHERE username='".$username."' && password='".$password."'";
	$query = mysql_query($sql) or die(mysql_error());
	$login_counter = mysql_num_rows($query);
	mysql_close();
	if ($login_counter > 0)
	{
		$data = mysql_fetch_array($query);
		if($data["status"]=="Pending")
		{
			header("Location:index.php?mode=inactive");
		}
		else if($data["status"]=="Block")
		{
			header("Location:index.php?mode=block");
		}
		else
		{
			$_SESSION['user'] = $data["username"];
			$_SESSION['type'] = $data["type"];
			if($_SESSION['type'] == "Admin" || $_SESSION['type'] == "Manager")
				header("Location:main.php");
			else
				header("Location:search.php");
		}
	}
	else
	{
		 header("Location:index.php?mode=invalid");
	}
}
else
{
	 header("Location:index.php?mode=fill");
}
?>