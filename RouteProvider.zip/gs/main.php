<!DOCTYPE html>
<?php
	error_reporting(0);
	include("session.php");
	$config = parse_ini_file("config.ini");
	$config['url'] = basename($_SERVER['SCRIPT_NAME']);
	$f = fopen("config.ini","w");
	foreach($config as $name => $value)
	{
		fwrite($f, "$name = \"$value\"\n");
	}
	fclose($f);
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>CHRP Library</title>
	<link rel='stylesheet' href='css/jquery-ui.css' />
	<link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
		//window.onbeforeunload = function() { return "You work will be lost."; };
	</script>
	<style>
		img
		{
			border : 0;
		}
	</style>
</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="">

	<div class="menu-card" align="center">
		<h1>Menu</h1>
		<a href="search.php" title="Search">
			<img src="images/search.png" width="90px" height="90px"></img><br/>
			Search			
		</a>
		<a href="upload.php" title="Upload">
			<img src="images/upload.png" width="90px" height="90px"></img><br/>
			Upload
		</a>
		<a href="userAccounts.php" title="User Accounts" style="<?php if($_SESSION['type'] == "Manager") echo 'display:none';else echo '';?>">
			<img src="images/accounts.png" width="90px" height="90px"></img><br/>
			Accounts
		</a>
		<a href="report.php" title="Report" style="<?php if($_SESSION['type'] == "Manager") echo 'display:none';else echo '';?>">
			<img src="images/report.png" width="90px" height="90px"></img><br/>
			Report
		</a>
	</div>
	
	<!--table width="100%" height="10px" style="position:fixed; left:0px; right:0px; bottom:0px;" border="0" cellpadding="5">
	<tr>
		<td align="center" style="color:#008ed2; font-size:12px;">
			Copyright &copy; CHRP-INDIA Pvt. Ltd., 2014
		</td>
	</tr>
	</table-->
</body>
</html>