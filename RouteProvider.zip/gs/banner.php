<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>CHRP Library</title>
	<link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
</head>
<body class="boxed">
	<table width="100%" height="47px" bgcolor="#ffffff" border="0" cellpadding="5">
	<tr>
		<td width="25%"><a href="http://www.chrp-india.com" target="_self"><img src="images/chrp.png" alt="logo" width="150px" height="45px" align="middle"/></a></td>
		<td width="50%" align="center"><img src="images/title.png" alt="title" height="46px" align="middle"/></td>
		<td width="25%" align="right">
			<div class="logout">
				<span style="color:#008ed2; font-size:14px; cursor:default;">Hi</span>&nbsp;|
				<a href="mailto:itdesk@chrp-india.com?Subject=CHRP Library - Help" style="color:#008ed2; font-size:14px;">Contact Admin</a>&nbsp;
			</div>
		</td>
	</tr>
	</table>
</body>
</html>