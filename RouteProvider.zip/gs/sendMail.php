<?php	
	if(isset($_POST['sbmtbtn']) && ($_POST['sbmtbtn'] != "") && 	
	isset($_POST['firstname']) && ($_POST['firstname'] != ""))
	{
		$name     = $_POST['firstname'];
		$email    = $_POST['email'];
		$phone    = $_POST['phone'];
		$jtitle    = $_POST['jtitle'];
		$org    = $_POST['org'];
		$enquiry = $_POST['enquiry'];
		
		require_once "Mail.php"; // PEAR Mail package 
		require_once ('Mail/mime.php'); // PEAR Mail_Mime packge

		$from   = "$email";
		$to     = "reach@chrp-india.com";
		$replyto  = "$email";
		$subject  = "Enquiry Form from " . $name;
		$headers  = array ('From' => $from,'To' => $to, 'Subject' => $subject, 'Reply-To' => $replyto);
		$headers1  = array ('From' => $to,'To' => $from, 'Subject' => 'Acknowledgement for your request to CHRP-INDIA', 'Reply-To' => $to);
      //$text   = 'Text version of email';// text and html versions of email. 
	  
	  
     $html     = '<html>
					<head>
						<title>CHRP-INDIA</title>
					</head>
					<body>
						<h3>Name: <span style="font-weight: normal;">' . $_POST['firstname'] . '</span></h3>
						<h3>Job Title: <span style="font-weight: normal;">' . $_POST['jtitle'] . '</span></h3>
						<h3>Organizatoin: <span style="font-weight: normal;">' . $_POST['org'] . '</span></h3>
						<h3>Contact Number: <span style="font-weight: normal;">' . $_POST['phone'] . '</span></h3>
						<h3>Email ID: <span style="font-weight: normal;">' . $_POST['email'] . '</span></h3>
						<h3>Enquiry: <span style="font-weight: normal;">' . $_POST['enquiry'] . '</span></h3>
						<div>
							<h3 style="margin-bottom: 5px;">Message:</h3>
							<div>' . nl2br($_POST['comment']) . '</div>
						</div>
					</body>
				</html>'; 
				
				
	$html1     = 'Dear ' . $_POST['firstname'] . ',
	
We would like to acknowledge that we have received your request and a ticket has been created.

A support representative will be reviewing your request and will send you a personal response.(usually within 8 hours).

Thank you for your patience.
						
Sincerely,
CHRP-INDIA Pvt. Ltd.
Support Team'; 			
           
        //$file = 'images/logo.jpg'; // attachment  
        $crlf = "\n"; 
        $mime = new Mail_mime($crlf); 
		
        //$mime->setTXTBody($text);  //when text is used
        $mime->setHTMLBody($html);  //when  HTML is used in body

		
        //$mime->addAttachment($file, 'text/plain');  //When attachment used
       
        $body      = $mime->get(); 
        $headers   = $mime->headers($headers); 
		
/*   

NORMAL WEBMAIL SETTINGS    */	
	
    #    $port      = "25";//For only google aps SMTP port try these (465 or 587).
	#	 $username  = "sending@labelhosting.com"; //Email Id
    #    $password  = "fafrUb7e"; //Password
    #    $username  = "webadmin@chrp-india.com"; //Email Id
    #    $password  = "web2015$$"; //Password
		
		/*   ----------   If you are suing  Google apps or Gmail as your Email use the below code indtad of above, Note to hide the above if using the below. */
		
       $host      = "smtp.gmail.com";
       $port      = "587";//For only google aps SMTP port try these (465 or 587).
	   $username  = "chrp.india2015@gmail.com"; //Email Id
       $password  = "CHRPindia2015"; //Password
		
	//
		
        $smtp      = Mail::factory('smtp', array ('host' => $host, 'port' => $port, 'auth' => true, 
        'username' => $username,'password' => $password)); 
        $mail = $smtp->send($to, $headers, $body);
        if (PEAR::isError($mail))
        { 
			echo("<p>" . $mail->getMessage() . "</p>");
			$gmsg = $mail->getMessage();
        } 
        else
         {
			 $gmsg = '<p class="send-true" style="color: #0183c0; margin-bottom:15px; border:1px solid #cccccc; padding: 10px;"><i>Thank you for your interest and writing in to us. Our representatives will review your requirements and connect with you over an e-mail within next 8 working hours.</i></p>';
			 $mail = $smtp->send($replyto, $headers1, $html1);
         }  				
	}
?>