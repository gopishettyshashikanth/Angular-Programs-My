<!DOCTYPE html>
<?php
include_once "connect.php";
$check = $_SESSION['user'];
$adminMail = 'itdesk@chrp-india.com';

$query = mysql_query("SELECT * FROM users WHERE username='$check'") or die(mysql_error());
$counter = mysql_num_rows($query);
if($counter <= 0)
{
	mysql_close();
	header("Location:index.php");
}
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>CHRP Library</title>
	<link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
</head>
<body class="boxed">
	<table width="100%" height="47px" bgcolor="#ffffff" border="0" cellpadding="5">
	<tr>
		<td width="25%"><a href="http://www.chrp-india.com/library/search.php" target="_self" ><img src="images/chrp.png" alt="logo" width="150px" height="45px" align="middle"/></a></td>
		<td width="50%" align="center"><img src="images/title.png" alt="title" height="46px" align="middle"/></td>
		<td width="25%" align="right">
			<div class="logout">
				<a href="profile.php" style="color:#008ed2; font-size:14px;">Hi <?php echo $_SESSION["user"];?></a>&nbsp;|
				<a href="mailto:<?php echo $adminMail;?>?Subject=CHRP Library - Help" style="color:#008ed2; font-size:14px;">Contact Admin</a><br/>
				<a href="index.php" style="color:#258; font-size:14px;">Log Out</a>
			</div>
		</td>
	</tr>
	</table>
	<br/>
</body>
</html>