<?php
function createThumbs( $fname, $pathToImages, $pathToThumbs, $size )
{
	$width = $new_width = $height = $new_height = 0;
	
	// open the directory
	$dir = opendir( $pathToImages );
	
	// parse path for the extension
	$info = pathinfo($pathToImages.$fname);

	// continue only if this is a JPEG image
	if (strtolower($info['extension']) == 'jpg' || strtolower($info['extension']) == 'png' || strtolower($info['extension']) == 'gif' || strtolower($info['extension']) == 'jpeg')
	{
		// load image and get image size
		switch($info['extension'])
		{
			case "jpg":
			case "jpeg":
				$img = imagecreatefromjpeg("{$pathToImages}{$fname}");
				break;
			case "gif":
				$img = imagecreatefromgif("{$pathToImages}{$fname}");
				break;
			case "png":
				$img = imagecreatefrompng("{$pathToImages}{$fname}");
				break;
			default:
				echo "Type is invalid, use an image file [ bmp, jpg, gif or png ]";
		}
		
		$width = imagesx($img);
		$height = imagesy($img);

		// calculate thumbnail size
		if($width >= $height)
		{
			$new_width = ($width<$size)?$width:$size;
			$h = floor($height*($size/$width));
			$new_height = ($h>$height)?$height:$h;
		}
		else if($width < $height)
		{
			$new_height = ($height<$size)?$height:$size;
			$w = floor($width*($size/$height));
			$new_width=($w>$width)?$width:$w;
		}

		// create a new tempopary image
		$tmp_img = imagecreatetruecolor( $new_width, $new_height );
			
		// create a new tempopary image for watermark
		$tmp_frm = imagecreatetruecolor( $new_width, $new_height );
		$frame = imagecreatefromstring(file_get_contents("images/watermark.png"));
		
		// Resize watermark
		//imagecopyresized( $tmp_frm, $frame, 0, 0, 0, 0, $new_width, $new_height, 800, 800 );

		// copy and resize old image into new image
		imagecopyresized( $tmp_img, $img, 0, 0, 0, 0, $new_width, $new_height, $width, $height );
		//imagecopyresized( $tmp_frm, $frame, 0, 0, 0, 0, $new_width, $new_height, $width, $height );

		// merge image with watermark image	
		imagecopymerge($tmp_img, $frame, 0, 0, 0, 0, imagesx($tmp_img), imagesy($tmp_img), 10);
		//imagecopymerge($tmp_img, $frame, 0, 0, -(imagesx($tmp_img)-imagesx($frame))/2, -(imagesy($tmp_img)-imagesy($frame))/2, imagesx($tmp_img), imagesy($tmp_img), 15);
			
		// save thumbnail into a file
		switch($info['extension'])
		{
			case "jpg":
			case "jpeg":
				imagejpeg( $tmp_img, "{$pathToThumbs}{$fname}" );
				//$t=file_get_contents("{$pathToThumbs}{$fname}");
				//echo "<img src=data:image/jpeg;base64,".base64_encode($t)." width='150px' height='120px'/>";
				break;
			case "gif":
				imagegif( $tmp_img, "{$pathToThumbs}{$fname}" );
				//$t=file_get_contents("{$pathToThumbs}{$fname}");
				//echo "<img src=data:image/jpeg;base64,".base64_encode($t)." width='150px' height='120px'/>";
				break;
			case "png":
				imagealphablending($tmp_img, false);
				imagesavealpha($tmp_img, true);
				imagepng( $tmp_img, "{$pathToThumbs}{$fname}" );
				//$t=file_get_contents("{$pathToThumbs}{$fname}");
				//echo "<img src=data:image/jpeg;base64,".base64_encode($t)." width='150px' height='120px'/>";
				break;
			default:
				echo "Type is invalid, use an image file [ bmp, jpg, gif or png ]";
		}
	}
	// close the directory
	closedir( $dir );
}
?>