<?php
include_once "connect.php";
date_default_timezone_set('Asia/Kolkata');

$user = $_GET['username'];
$file = $_GET['filename'];
$path = 'uploads/'.$file;
$type = "download";
$dt = date('d M Y h:i a');
$stat = "success";

$url = json_decode(file_get_contents("http://api.ipinfodb.com/v3/ip-city/?key=2b3d7d0ad1a285279139487ce77f3f58d980eea9546b5ccc5d08f5ee62ce7471&ip=".$_SERVER['REMOTE_ADDR']."&format=json"));
$loc = $url->ipAddress.",".$url->cityName.",".$url->countryName;

if(!$path)
{
    die('file not found');
}
else
{
	//turn off output buffering to decrease cpu usage
	@ob_end_clean();

    header("Cache-Control: public");
    header("Content-Description: File Transfer");
    header("Content-Disposition: attachment; filename=$file");
    header("Content-Type: application/force-download");
    header("Content-Transfer-Encoding: binary");
	header("Content-Length: ".filesize($path));
	
	header("Cache-control: private");
	header('Pragma: private');
	
    // read the file from disk
    readfile($path, "r");
}

$sql = "INSERT INTO report (username, location, filename, type, time_date, status) VALUES ('".$user."', '".$loc."', '".$file."', 'download', '".$dt."' ,'success')";
$result = mysql_query($sql) or die(mysql_error());
mysql_close();
?>