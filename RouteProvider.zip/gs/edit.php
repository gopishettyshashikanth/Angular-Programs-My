<!DOCTYPE html>
<?php
	include("session.php");
		
	$id = $_GET['id'];
	$mode = $_GET['mode'];

	$sql = "SELECT * FROM images WHERE id='$id';";
	$query = mysql_query($sql) or die(mysql_error());
	$data = mysql_fetch_array($query);

	$filename = $data['name'];
	$name = explode(".",$filename)[0];
	$extension = explode(".",$filename)[1];
	$tag = $data['tag'];
	
	$url = "editFile.php?id=".$id."&fname=".$filename."&ext=".$extension;
	mysql_close();
	if($mode == 'success')
	{
		$color = "#008000";
		$Error = 'File updated successfully!';
	}
	else if($mode == 'exist')
	{
		$color = "#ff0000";
		$Error = 'File name is already existed!';
	}
	else if($mode == '')
	{
		$color = "#ffffff";
		$Error = '';
	}

	$images = ["jpg","jpeg","png","gif"];
	
	if(in_array($extension, $images))
	{
		$path = "thumbs/".$filename;
	}
	else
	{
		$jpg = explode(".",$filename)[0].".jpg";
		$path = "thumbs/".$jpg;
	}

	//echo $name."<br/>".$path."<br/>".$filename."<br/>".$extension;
?>
<html>
<head>
	<meta charset="UTF-8" />
	<title>CHRP Library</title>
	<link rel='stylesheet' href='css/jquery-ui.css' />
    <link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
	<script src="js/jquery-1.11.1.min.js"></script>
	<script language="javascript" type="text/javascript">
		window.history.forward();
		function noBack()
		{
			window.history.forward();
		}
		//window.onbeforeunload = function() { return "You work will be lost."; };
	</script>
	<script language="javascript" type="text/javascript">
		function fillData()
		{
			document.getElementById('name').value = "<?php echo $name;?>";
			document.getElementById('cate').value = "<?php echo $data['category'];?>";
			document.getElementById('tag').value = "<?php echo $tag;?>";
			document.getElementById('img').src = "<?php echo $path;?>";
			document.getElementById("submit").disabled = false;
		}
		function clearData()
		{
			document.getElementById('name').value = "";
			document.getElementById('cate').value = "";
			document.getElementById('tag').value = "";
			document.getElementById("submit").disabled = true;
		}
		function enableSubmit()
		{	
			if(document.getElementById('name').value == "" || document.getElementById('cate').value == "" || document.getElementById('tag').value == "")
			{
				document.getElementById("submit").disabled = true;
			}
			else
			{
				document.getElementById("submit").disabled = false;
			}
			document.getElementById("error").innerText = "";
		}
	</script>
	<script>
		$(document).ready(function()
		{
			$('input#name').keyup(function()
			{
				enableSubmit();
			});
			$('textarea#tag').keyup(function()
			{
				enableSubmit();
			});
			$('input#clear').click(function()
			{			
				clearData();
			});
		});
	</script>
</head>
<body onload="noBack(); fillData();" onpageshow="if (event.persisted) noBack();" onunload="">

	<div class="search-card">
		<h1>Edit</h1>
		<div height="500px">
			<div style="float:left; width:50%; height:300px;" align="center">
				<img id="img" width="300px" height="250px" style="padding:20px;"/>
			</div>
			<div style="float:right; width:50%; height:300px;" align="center">
				<br/>
				<form method="post" id="editForm" action="<?php echo $url;?>" >
					<input name="name" type="text" id="name" placeholder="File Name" style="height:35px; width:95%;" maxlength="45" />
					<select name="category" id="cate" style="height:35px; width:95%;" onchange="enableSubmit();">
						<option value="" selected>Select Category</option>
						<option value="Images">Images</option>
						<option value="Vectors">Vectors</option>
						<option value="Illustrations">Illustrations</option>
						<option value="Storyline">Storyline</option>
						<option value="Captivate">Captivate</option>
						<option value="Videos">Videos</option>
						<option value="Audio">Audio</option>
						<option value="Flash">Flash</option>	
					</select>
					<textarea class="form-control" name="tag" id="tag" placeholder="Enter key words for searching this image" style="max-width:90%; min-height:70px; max-height:80px; width:90%;" maxlength="255"></textarea>
					<div style="margin:0 auto; overlay:hidden;">
						<input name="reset" type="button" id="reset" value="Reset" style="height:35px; width:90px;" onclick="fillData();"/>
						<input name="clear" type="button" id="clear" value="Clear All" style="height:35px; width:90px;"/>
						<input name="submit" type="submit" id="submit" value="Submit" style="height:35px; width:90px;"/>
					</div>
				</form>
			</div>
		</div>
		<div id="error" align="center" style="color:<?php echo $color;?>;"><?php echo ((isset($Error) && $Error != '') ? $Error : ''); ?></div>
		<br/>
		<div class="login-help">
			<a href="search.php">Back to Search</a>
		</div>
	</div>
	
	<!--table width="100%" height="10px" style="position:fixed; left:0px; right:0px; bottom:0px;" border="0" cellpadding="5">
	<tr>
		<td align="center" style="color:#008ed2; font-size:12px;">
			Copyright &copy; CHRP-INDIA Pvt. Ltd., 2014
		</td>
	</tr>
	</table-->
</body>
</html>