(function(){
	
	angular.module("student")
	
			.service("studentSvc",["$http",function($http){
				
				this.getStdDetails = function(){
				
				return $http.get("API/studentDetails.json");
				
				}
							
				this.getStdMarks = function(){
				
				return $http.get("API/marks.json");
				
				}	
							
			}]);
})();